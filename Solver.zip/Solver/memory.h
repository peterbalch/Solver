//==============
// memory.h
//==============

#ifndef memory_h
#define memory_h

#include "calcdecl.h"
#include <stdint.h>

Pnode new_node(Toperation oper);
PReferenceRec NewReferenceRec(Pnode ref);
void FreeAllMemory();
void *GetBufferMemory(uint16_t size);

extern int32_t memtop;

#endif
