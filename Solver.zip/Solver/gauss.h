//==============
// gauss.h
//==============

#ifndef gauss_h
#define gauss_h

#include <stdint.h>

bool gaussian_eliminate();
double getMatrix(int8_t x, int8_t y);
void setMatrix(int8_t x, int8_t y, double a);
double getTestMatrix(int8_t x, int8_t y);
void setTestMatrix(int8_t x, int8_t y, double a);
bool AllocateMatrix();
void ResetMatrix();

extern int8_t matSize;

#endif
