//==============
// memory.cpp
//==============

#include "memory.h"
#include "VDU.h"
#include <stdlib.h>

int32_t memtop = 0;
uint8_t *membuffer = nullptr;
#define membufferLen 100000

/*-------- Buffer ----------------------------------------------------*/
void *GetBufferMemory(uint16_t size)
{
  if (membuffer == nullptr)
    membuffer = (uint8_t*) malloc(100000);
    
  if (memtop+size >= membufferLen)
  {
    RunError(1,-3);
    return nullptr;
  } else
  {
    memtop = memtop+size;
    return &membuffer[memtop-size];
  }
}

/*-------- Nodes ----------------------------------------------------*/
Pnode new_node(Toperation oper)
{
  Pnode t;
  
  t = (Pnode)GetBufferMemory(sizeof(*t));
  if (t == nullptr)
    return nullptr;

  t->B.op = oper;
  switch (oper) {
    case opVar:
    case opCnst:
        t->V.value = 0;
        t->V.init_value = 0;
        t->V.name[0] = 0;
        t->V.initialised = false;
        t->V.nextV = nullptr;
        t->V.status = unknown;
        break;

    default:
      t->B.Left = nullptr;
      t->B.Right = nullptr;
  }
  return t;
}

/*-------- ReferenceRec ----------------------------------------------------*/
PReferenceRec NewReferenceRec(Pnode ref)
{
  PReferenceRec t;

  t = (PReferenceRec)GetBufferMemory(sizeof(*t));
  if (t == nullptr)
    return nullptr;

  t->ref = ref;
  t->nextR = local_name_list;
  local_name_list = t;
  return t;
}

/*----------------------------------------------------------------------*/
void FreeAllMemory()
{
  memtop = 0;
}
