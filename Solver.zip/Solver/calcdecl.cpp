//==============
// calcdecl.cpp
//==============

#include "calcdecl.h"
#include <stdint.h>
#include "memory.h"
#include "math.h"
#include <string.h>
#include <limits.h>

#define TXTH TextHeight(CurFont)+1
#define odd(i) ((i & 1) > 0)

double MaxRealDbl = 8e307;
float MaxRealSgl = 8e38;
Pnode global_name_list;
PReferenceRec local_name_list;
TequRec equations[equMax+2];
bool has_qus,has_fors,has_plot;
bool is_solving = false;
bool is3Dplot;
uint16_t Iterations = 100;
double Accuracy = 1e-9;
bool hasQuInLine;

double frac(double a) {
  double i;
  return modf(a,&i);
}

void strReal(double r, int8_t len,  char *buf)
{
  int8_t i;
  int16_t expon;
  char s[6];

  if (r < 0)    
  {
    strReal(-r,len-1, (char*)(&buf[1]));
    buf[0] = '-';
    return;
  }

  if (r == 0) 
  {
    buf[0] = '0';
    buf[1] = 0;
    return;
  }

  expon = 0;
  while (r >= 10) 
  {
    expon++;
    r = r/10;
  }
  while (r < 1)
  {
    expon--;
    r = r*10;
  }

  if ((expon > 6) || (expon < -5))
  {
    strReal(expon,4,(char*)(&s[1]));
    s[0] = 'e';
    strReal(r,len-strlen(s),buf);
    strcat(buf,s);
    return;
  }

  if (expon < 0)
  {
    strcpy(buf,"0.");
    while (expon < -1)
    {
      buf[strlen(buf)+1] = 0;
      buf[strlen(buf)] = '0';
      expon++;
    }

    while ((strlen(buf) < len+1) && (r > 0))
    {
      buf[strlen(buf)+1] = 0;
      buf[strlen(buf)] = char('0'+safeTrunc(r));
      r = (r-safeTrunc(r))*10;
    }
  } else
  {
    buf[0] = 0;
    while ((strlen(buf) < len+1) && (expon >= 0))
    {
      expon--;
      buf[strlen(buf)+1] = 0;
      buf[strlen(buf)] = char('0'+safeTrunc(r));
      r = (r-safeTrunc(r))*10;
    }
    if (r > 1e-9)
    {
      buf[strlen(buf)+1] = 0;
      buf[strlen(buf)] = '.';
      while ((strlen(buf) < len+1) && (r > 1e-10))
      {
        buf[strlen(buf)+1] = 0;
        buf[strlen(buf)] = char('0'+safeTrunc(r));
        r = (r-safeTrunc(r))*10;
      }
    }
  }

  if (strlen(buf) == len+1)
  {
    if (buf[strlen(buf)-1] >= '5')
    {
      i = strlen(buf)-1;
      do {
        buf[i] = '0';
        i--;
        if (buf[i] == '.')
          i--;
        buf[i]++;
      } while (!((buf[i] <= '9') || (i == 0)));

      if ((i == 0) && ((buf[0] == '0') || (buf[0] > '9')))
      {
        buf[0] = '0';
        for (i = strlen(buf)-1; i>=1; i--)
          buf[i] = buf[i-1];
        buf[0] = '1';
      }
    }

    while (buf[strlen(buf)-1] == '0')
      buf[strlen(buf)-1] = 0;
    if (buf[strlen(buf)-1] == '.')
      buf[strlen(buf)-1] = 0;
    buf[len] = 0;
/*
    if (strlen(buf) == 0)
    {
      buf[0] = '1';
      buf[1] = '0';
    }
*/
  }
}

char *real_str(double r)
{
  static char s[31];
  strReal(r,NumLength,(char*)(&s[0]));
  return (char*)(&s[0]);
}

double safeDiv(double a, double b)
{
  if (b == 0) return 0; else return a/b;
}

int32_t safeTrunc(double r)
{
  if (r >  LONG_MAX) return LONG_MAX; else
  if (r < -LONG_MAX) return -LONG_MAX; else
    return (int32_t)r;
}

void CopyStringN(char *dest, char *src, int8_t n)
{
  int8_t i;
  dest[n-1] = 0;
  i = 0;
  while ((*src != 0) && (i < n))
  {
    dest[i] = *src;
    src++;
    i++;
  }
  dest[i] = 0;
}
