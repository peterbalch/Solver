//==============
// Plotter.h
//==============

#ifndef Plotter_h
#define Plotter_h

#include "calcdecl.h"

enum Taxis_type {x_axis,y_axis,z_axis};

void PlotterFormKeyPress(char Key);
void DrawImagePlot();
void ResetPlot();
void coord(Taxis_type ax, double v, Pnode varb);
  // called when one coordinate value has been found
void NewPlotLine();
  // called after a for loop has finished - starts a new line
void CoordsFound();
  // called after equs has been solved once but before calls to coord
void AllCoordsFound();
  // called when all coords have been found


#endif
