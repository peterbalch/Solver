/***************************************************
  Arduino TFT graphics library for the ILI9341

  modified to work with ESP32

  The Touch and DrawBitmap functions have not been tested in this version but the same code works well on a Nano/Uno

  Derived from the TFT_ILI9341 library which was
  derived from the Adafruit_GFX library and the
  associated driver library.

 ****************************************************/

#ifndef SimpleILI9341_h
#define SimpleILI9341_h

#include <SPI.h>
//#include "Adafruit_SPIDevice.h"

extern int16_t Cursorx, Cursory;
extern uint16_t tft_width, tft_height; // Display w/h
extern bool execDrawChar;
extern uint8_t pen_width; // if pen_width > 1 then draws with a disc of radius pen_width
extern bool ILI9341fast; // true is faster but can interfere with other devices on SPI bus; false shares the SPI bus better
extern uint8_t letter_gap;

// ILI9341 rotation values
#define ILI9341_MADCTL_MY  0x80
#define ILI9341_MADCTL_MX  0x40
#define ILI9341_MADCTL_MV  0x20
#define ILI9341_MADCTL_ML  0x10
#define ILI9341_MADCTL_RGB 0x00
#define ILI9341_MADCTL_BGR 0x08
#define ILI9341_MADCTL_MH  0x04

#define ILI9341_Rotation0  (ILI9341_MADCTL_MX | ILI9341_MADCTL_BGR)
#define ILI9341_Rotation1  (ILI9341_MADCTL_MV | ILI9341_MADCTL_BGR)
#define ILI9341_Rotation2  (ILI9341_MADCTL_MY | ILI9341_MADCTL_BGR)
#define ILI9341_Rotation3  (ILI9341_MADCTL_MX | ILI9341_MADCTL_MY | ILI9341_MADCTL_MV | ILI9341_MADCTL_BGR)

void ILI9341Begin(uint8_t CS = 10, uint8_t CD = 8, uint8_t RST = 7, uint16_t w = 320, uint16_t h = 240, uint8_t Rotation = ILI9341_Rotation1);
void ILI9341SetCursor(uint16_t x, uint16_t y);
void ClearDisplay(uint16_t color);
void DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void DrawHLine(uint16_t x, uint16_t y, uint16_t w, uint16_t color);
void DrawVLine(uint16_t x, uint16_t y, uint16_t h, uint16_t color);
void DrawBox(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void DrawFrame(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void DrawRoundRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t rad, uint16_t color);
void DrawCircle(uint16_t x0, uint16_t y0, uint16_t rad, uint16_t color);
void DrawDisc(uint16_t x0, uint16_t y0, uint16_t rad, uint16_t color);
void DrawFilledEllipse(int x0, int y0, int rx, int ry, uint16_t color);
void DrawEllipse(int x0, int y0, int rx, int ry, uint16_t color);
void DrawTriangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void DrawChar(uint8_t c, const char *Font, uint16_t color);
void DrawString(char *s, const char *Font, uint16_t color);
void DrawStringAt(int16_t x, int16_t y, char *s, const char *Font, uint16_t color);
void DrawInt(int i, const char *Font, uint16_t color);
void DrawFloat(float floatNumber, int dp, const char *Font, uint16_t color);
void InvertDisplay(bool i);
uint16_t rgb(uint8_t r, uint8_t g, uint8_t b);
void DrawBitmap(int16_t x, int16_t y, const unsigned short *bitmap);
void DrawBitmapMono(int16_t x, int16_t y, const uint8_t *bitmap, uint16_t color);
int TextWidth(char *s, const char *Font);
int TextHeight(const char *Font);

void BeginTouch(uint8_t CS = 2, uint8_t Rotation = 1, int xmin = 320, int ymin = 320, int xmax = 3900, int ymax = 3900);
bool GetTouch(int *x, int *y);

#include <Arduino.h>

// color definitions

#define RGB(r, g, b)  (((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3))
#define TFT_BLACK       RGB(0,   0,   0)
#define TFT_NAVY        RGB(0,   0, 128)
#define TFT_DARKGREEN   RGB(0, 128,   0)
#define TFT_DARKCYAN    RGB(0, 128, 128)
#define TFT_MAROON      RGB(128,   0,   0)
#define TFT_PURPLE      RGB(128,   0, 128)
#define TFT_OLIVE       RGB(128, 128,   0)
#define TFT_LIGHTGREY   RGB(192, 192, 192)
#define TFT_LIGHTGRAY   RGB(192, 192, 192)
#define TFT_DARKGREY    RGB(128, 128, 128)
#define TFT_DARKGRAY    RGB(128, 128, 128)
#define TFT_BLUE        RGB(0,   0, 255)
#define TFT_GREEN       RGB(0, 255,   0)
#define TFT_CYAN        RGB(0, 255, 255)
#define TFT_RED         RGB(255,   0,   0)
#define TFT_MAGENTA     RGB(255,   0, 255)
#define TFT_YELLOW      RGB(255, 255,   0)
#define TFT_WHITE       RGB(255, 255, 255)
#define TFT_ORANGE      RGB(255, 165,   0)

extern const char SmallFont[];
extern const char CompactFont[];
extern const char MediumFont[];
extern const char LargeFont[];
extern const char DigitsFont[];

#endif
