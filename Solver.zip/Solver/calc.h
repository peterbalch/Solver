//==============
// calc.h
//==============

#ifndef calc_h
#define calc_h

#include "calcdecl.h"

double calculate(Pnode tree, int8_t *err);
double execMultiply(double a, double b, int8_t *err);
double execDivide(double a, double b, int8_t *err);
double execPower(double a, double b, int8_t *err);
double execExponential(double a, int8_t *err);
double execNat_log(double a, int8_t *err);
double execArcsine(double a, int8_t *err);
double execArccosine(double a, int8_t *err);
double execArctangent(double a, int8_t *err);
double execSine(double a, int8_t *err);
double execCosine(double a, int8_t *err);
double execTangent(double a, int8_t *err);

extern bool calculate_value_known; // returned by calculate


#endif
