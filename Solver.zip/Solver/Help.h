//==============
// Help.h
//==============

#ifndef Help_h
#define Help_h

#include <stdint.h>
#include "calcdecl.h"

int16_t ShowHelpPage(int16_t page, int16_t link, int16_t VOffset);
void HelpKeyPress(char Key);

#endif
