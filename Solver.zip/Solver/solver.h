//==============
// solver.h
//==============

#ifndef solver_h
#define solver_h

bool solve_strings();

#endif
