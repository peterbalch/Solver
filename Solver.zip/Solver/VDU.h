//==============
// VDU.h
//==============

#ifndef VDU_h
#define VDU_h

#include <stdint.h>

enum TImageMode {imEdit,imSolved_edit,imEdit_solved,imHelp};

#define NumLines 50
#define lenLineStr 100

extern char lines[NumLines][lenLineStr];
extern TImageMode ImageMode;

void ResetVDU();
void LinesClear(bool draw);
void ButtonDown(int8_t aTag);
void ButtonUp();
void SetImageMode(TImageMode im);
void FormKeyClick(char Key);
bool MoveEditorCursor(int16_t x,int16_t y);
void DrawImageEditor();
void DrawEditorLine(int16_t i);
void ShowErrorAt(int16_t x,int16_t y, char  *str);
void DeleteAnswers();
void InsertAnswer(int16_t x,int16_t y, char  *s);
void InsertChar(char  *dest, char c, int16_t n);
void CopyLineString(char  *dest,char  *src);
void AddQuLine(char  *varName);
void SolveBtnClicked();
void Timer();
void RunError(int8_t equNum,int8_t errnum);
void SerialReceived(char c);

#endif
