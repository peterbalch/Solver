//==============
// Storage.cpp
//==============

#include "Storage.h"
#include "calcdecl.h"
#include "VDU.h"
#include <stdint.h>
#include <string.h>
#include <EEPROM.h>

#define EEPROMsignature  "Sol"
#define EEPROMaccuracy  strlen(EEPROMsignature)
#define EEPROMiterations  EEPROMaccuracy+sizeof(double)
#define EEPROMstart  EEPROMiterations+sizeof(uint32_t)

//void add1Click(); // not in calculator
//void initWithSamples(); // not in calculator
//void listClick(); // not in calculator
//char EEPROMx[EEPROMsize];
uint32_t CurFileIdNum;

void IncEEPROMAddr(int16_t *addr, int16_t n)
{
  for (int16_t i = 1; i<=n; i++)
  {
    (*addr)++;
    if (*addr >= EEPROMsize)
      *addr = EEPROMstart;
  }
}

uint32_t IncIdNum(uint32_t id_num)
{
  do {
    id_num++;
  } while (!( ((id_num & 0xFF) != 1) & (((id_num >> 8) & 0xFF) != 1) & (((id_num >> 16) & 0xFF) != 1) & (((id_num >> 24) & 0xFF) != 1)));
  return id_num;
}

int8_t getEEPROM(int16_t addr)
{
//  return EEPROMx[addr];

  int8_t i;
  EEPROM.get(addr, i); 
  return i;
}

void setEEPROM(int16_t addr, int8_t i)
{
//  EEPROMx[addr] = i;

  EEPROM.put(addr, i);
}

void EEPROMgetBuf(void *Buf, int16_t *addr, int16_t len)
{
  char *p = (char*)Buf;
  for (int16_t i = 1; i<=len; i++)
  {
    *p = getEEPROM(*addr);
    IncEEPROMAddr(addr,1);
    p++;
  }
}

void EEPROMsetBuf(void *Buf, int16_t *addr, int16_t len)
{
  char *p = (char*)Buf;
  for (int16_t i = 1; i<=len; i++)
  {
    setEEPROM(*addr,*p);
    IncEEPROMAddr(addr,1);
    p++;
  }
}

int32_t EEPROMgetInt32(int16_t *addr)
{
  int32_t result;
  EEPROMgetBuf(&result,addr,sizeof(result));
  return result;
}

void EEPROMsetInt32(int16_t *addr, int32_t value)
{
  EEPROMsetBuf(&value,addr,sizeof(value));
}

uint32_t EEPROMgetDWORD(int16_t *addr)
{
  uint32_t result;
  EEPROMgetBuf(&result,addr,sizeof(result));
  return result;
}

void EEPROMsetDWORD(int16_t *addr, uint32_t value)
{
  EEPROMsetBuf(&value,addr,sizeof(value));
}

double EEPROMgetDbl(int16_t *addr)
{
  double result;
  EEPROMgetBuf(&result,addr,sizeof(result));
  return result;
}

void EEPROMsetDbl(int16_t *addr, double value)
{
  EEPROMsetBuf(&value,addr,sizeof(value));
}

int32_t EEPROMnextFileAddr(int16_t addr)
/* addr points at the uint8_t after the id_num of the file*/
/* result points at the uint8_t after the final 0 of the file*/
{
  while (getEEPROM(addr) != 0)
    IncEEPROMAddr(&addr,1);
  IncEEPROMAddr(&addr,1);
  return addr;
}

int16_t EEPROMhighestFileAddr(uint32_t amin, uint32_t amax)
/* result points at the id_num of the file with the highest id_num where amin < id_num < amax */
{
  int16_t a,addr;
  uint32_t top,id_num;
  int16_t result;

  result = 0;
  top = 0;
  addr = EEPROMstart;
  for (int16_t n = 1; n<=EEPROMsize; n++)
  {
    if (getEEPROM(addr) == 1)
    {
      IncEEPROMAddr(&addr,1);
      a = addr;
      id_num = EEPROMgetInt32(&addr);
      if ((id_num > top) && (id_num > amin) && (id_num < amax))
      {
        top = id_num;
        result = a;
      }
    }
    IncEEPROMAddr(&addr,1);
  }
  return result;
}

//void EEPROMSaveFile(char *s) // not in calculator
///*returns id_num of saved file*/
///*id_num ! allowed to be 0 || contain a 1 uint8_t*/
//{
//  int16_t addr;
//  
//  addr = EEPROMhighestFileAddr(0,0xFFFFFFFF);
//  if (addr > 0)
//  {
//    CurFileIdNum = EEPROMg32(&addr);
//    addr = EEPROMnextFileAddr(addr);
//  } else
//  {
//    CurFileIdNum = 0;
//    addr = EEPROMstart;
//  }
//
//  CurFileIdNum = IncIdNum(CurFileIdNum);
//
//  setEEPROM(addr, 1);
//  IncEEPROMAddr(&addr,1);
//  EEPROMsetInt32(&addr,CurFileIdNum);
//  while (*s != 0)
//  {
//    setEEPROM(addr, *s);
//    IncEEPROMAddr(&addr,1);
//  }
//  setEEPROM(addr, 0);
//
//    EEPROM.commit();
//}

bool FileChanged(int16_t addr)
/*returns id_num of saved file*/
{
  EEPROMgetInt32(&addr);

  for (int8_t y = 0; y<NumLines; y++)
  {
    int8_t x = 0;
    while (lines[y][x] != 0)
    {
      if (getEEPROM(addr) != lines[y][x])
        return true;
      IncEEPROMAddr(&addr,1);
      x++;
    }
    if (getEEPROM(addr) != '\r')
      return true;
    IncEEPROMAddr(&addr,1);
  }
  if (getEEPROM(addr) != 0)
    return true;
  return false;
}

void SaveFile()
/*returns id_num of saved file*/
/*id_num ! allowed to be 0 || contain a 1 uint8_t*/
{
  int16_t maxline,addr;
  maxline = 0;
  for (int8_t y = 0; y<NumLines; y++)
    if (lines[y][0] != 0)
      maxline = y;
  if (lines[maxline][0] == 0)
    return; // empty file

  addr = EEPROMhighestFileAddr(0,0xFFFFFFFF);
  if (addr > 0)
  {
    if (! FileChanged(addr))
      return;
    CurFileIdNum = EEPROMgetInt32(&addr);
    addr = EEPROMnextFileAddr(addr);
  } else
  {
    CurFileIdNum = 0;
    addr = EEPROMstart;
  }

  CurFileIdNum = IncIdNum(CurFileIdNum);
  setEEPROM(addr, 1);
  IncEEPROMAddr(&addr,1);
  EEPROMsetInt32(&addr,CurFileIdNum);

  for (int8_t y = 0; y<=maxline; y++)
  {
    int8_t x = 0;
    while (lines[y][x] != 0)
    {
      setEEPROM(addr, lines[y][x]);
      IncEEPROMAddr(&addr,1);
      x++;
    }
    setEEPROM(addr, '\r');
    IncEEPROMAddr(&addr,1);
  }
  setEEPROM(addr, 0);

  EEPROM.commit();
}


void LoadFile(uint32_t amin, uint32_t amax)
{
  int16_t i,addr;
  
  addr = EEPROMhighestFileAddr(amin,amax);
  if (addr > 0)
  {
    LinesClear(false);
    i = 0;
    CurFileIdNum = EEPROMgetInt32(&addr);
    while (getEEPROM(addr) != 0)
    {
      if (getEEPROM(addr) == '\r')
        i++; else
        InsertChar(lines[i],getEEPROM(addr),1000);
      IncEEPROMAddr(&addr,1);
    }
    SetImageMode(imEdit);
  }
}

void LoadLastFile()
{
  LoadFile(0,0xFFFFFFFF);
}

void LoadPrevFile()
{
  LoadFile(0,CurFileIdNum);
}

void LoadNextFile()
{
  LoadFile(0,IncIdNum(IncIdNum(CurFileIdNum)));
}

//void listClick() // not in calculator
//{
//  char s[10000];
//  int16_t addr,n;
//  uint32_t amax,cur;
//
//  s[0] = 0;
//  cur = CurFileIdNum;
//  amax = 0xFFFFFFFF;
//  while (true)
//  {
//    addr = EEPROMhighestFileAddr(0,amax);
//    if (addr > 0)
//    {
//      amax = EEPROMgetInt32(&addr);
//      strcat(s,"File ");
//      sprintf(s+strlen(s),"%d",amax);
//      strcat(s,"\r\n");
//
//      while (getEEPROM(addr) != 0)
//      {
//        sprintf(s+strlen(s),"%c",getEEPROM(addr));
//        if (getEEPROM(addr) == '\r')
//          sprintf(s+strlen(s),"%c",'\r');
//        IncEEPROMAddr(&addr,1);
//      }
//      strcat(s,"\r\n\r\n");
//    } else
//    {
////      ShowInformationMessage(s);
//
//      for (addr = 0; addr < EEPROMsize; addr++)
//        if (getEEPROM(addr) != 0)
//          n = addr;
////      InputMemo("EEPROM','Files ("+inttostr(n)+" of "+inttostr(EEPROMsize)+')',s);
//      CurFileIdNum = cur;
//      return;
//    }
//  }
//}

/*
void initWithSamples()
{
  EEPROMSaveFile(
    "x=3\r"\
    "x*x=?\r"\
    "x*x*x=?\r\r");
  EEPROMSaveFile(
    "sin(?^2+0.1)=0.4\r\r");
  EEPROMSaveFile(
    "a = for 0 to 5 by 0.1\r"\
    "sin(a) =?\r"\
    "a = ?\r\r");
  EEPROMSaveFile(
    "x = for 0 to 5 by 0.1\r"\
    "sin(x) = y\r\r");
  EEPROMSaveFile(
    "y = for 0.1, 0.5, 1.0\r"\
    "sin(x+y) = 2*x\r"\
    "x = ?\r\r");
  EEPROMSaveFile(
    "sin(x+ for 0.1,0.5,0.7) = 2*x\r"\
    "x = ?\r\r");
  EEPROMSaveFile(
    "5*x-x*x-6 = 0\r"\
    "x=?\r\r");
  EEPROMSaveFile(
    "5*x-x*x-6 = 0\r"\
    "x=<2>\r\r");
  EEPROMSaveFile(
    "x*x = 2*x + 15\r"\
    "x= ?\r\r");
  EEPROMSaveFile(
    "x=<-3.24264068>\r\r");
  EEPROMSaveFile(
    "x=<5.242640687>\r\r");
  EEPROMSaveFile(
    "x=<-3.24264068>\r\r");
  EEPROMSaveFile(
    "init(x) = 5\r\r");
  EEPROMSaveFile(
    "x=<5.242640687>\r\r");
  EEPROMSaveFile(
    "x*x+2*x*y=32\r"\
    "y*y+x=y+15\r"\
    "x=?\r"\
    "y=?\r\r");
  EEPROMSaveFile(
    "x=<2.923603392>\r"\
    "y=<4.010896838>\r\r");
  EEPROMSaveFile(
    "init(x)=-14\r"\
    "init(y)=6\r\r");
  EEPROMSaveFile(
    "x=<-14.1047439>\r"\
    "y=<5.918001837>\r\r");
  EEPROMSaveFile(
    "init(x)=-3\r"\
    "init(y)=-4\r\r");
  EEPROMSaveFile(
    "x=<-3.02577347>\r"\
    "y=<-3.77501736>\r\r");
  EEPROMSaveFile(
    "init(x)=8\r"\
    "init(y)=-2\r\r");
  EEPROMSaveFile(
    "x=<8.206913995>\r"\
    "y=<-2.15388130>\r\r");
  EEPROMSaveFile(
    "a = for -2 to 1 by 1\r"\
    "b = for 1 to 3 by 1\r"\
    "x*x+a=0\r"\
    "y*y+b=5\r"\
    "a=?\r"\
    "b=?\r"\
    "x=?\r"\
    "y=?\r\r");
  EEPROMSaveFile(
    "p = for 1 to 2 by 1\r"\
    "q = for 1,10,100\r"\
    "r = for 7 to 6 by -1\r"\
    "p=?\r"\
    "q=?\r"\
    "r=?\r\r");
  EEPROMSaveFile(
    "a = for 0 to 3 by 0.5\r"\
    "a = ?[15]\r"\
    "b = a*a\r"\
    "b = ?\r\r");
  EEPROMSaveFile(
    "x = for 50 to 1 by -1\r\r");
  EEPROMSaveFile(
    "a = for 5 to 1 by 1\r\r");
  EEPROMSaveFile(
    "sin(x)-0.5=0\r\r");
  EEPROMSaveFile(
    "init(x)=0.5\r\r");
  EEPROMSaveFile(
    "x=<0.523598775>\r\r");
  EEPROMSaveFile(
    "sin(x)-0.5=0\r"\
    "x= ?[49]\r"\
    "init(x)=for 0 to 10 by 1\r\r");
  EEPROMSaveFile(
    "x = for 0 to 5 by 0.1\r"\
    "sin(x) = y\r\r");
  EEPROMSaveFile(
    "x = for 0 to 10 by 1\r"\
    "y = for 0 to 10 by 1\r"\
    "x*(10-x)*y*y*(10-y) = z\r\r");
  EEPROMSaveFile(
    "? = resistance\r\r"\
    "voltage/time = ?\r\r");
  EEPROMSaveFile(
    "x=2*sin(?)\r\r");
  EEPROMSaveFile(
    "p=for -2,-1,2,3\r"\
    "x=for -10 to 10 by 0.2\r"\
    "x^p=y\r\r");
  EEPROMSaveFile(
    "x*x = 2*x + 17\r"\
    "x= ?[15]\r\r");
  EEPROMSaveFile(
    "x=<5.242640687>\r"\
    "x=<-3.24264068>\r\r");
  EEPROMSaveFile(
    "init(x)=5\r");
  EEPROMSaveFile(
    "x=<5.242640687>\r\r");
  EEPROMSaveFile(
    "init(x)=-3\r");
  EEPROMSaveFile(
    "x=<-3.24264068>\r\r");
  EEPROMSaveFile(
    "x*x = 2*x + 16 +y\r"\
    "x = for -10 to 10 by 1\r\r");
  EEPROMSaveFile(
    "x*x+2*x*y=32\r"\
    "y*y+x=y+15\r"\
    "x= ?[15]\r"\
    "y=?\r\r");
  EEPROMSaveFile(
    "x = for 0 to 5 by 0.1\r"\
    "b = for 0 to 0.5 by 0.1\r"\
    "sin(x+b) = y\r\r");
  EEPROMSaveFile(
    "b = for 0 to 0.5 by 0.1\r"\
    "x = for 0 to 5 by 0.1\r"\
    "sin(x+b) = y\r\r");
  EEPROMSaveFile(
    "q=for 1 to 10 by 4\r"\
    "p=for 1 to 3 by 1\r"\
    "p+q=x\r"\
    "1=y\r\r");
  EEPROMSaveFile(
    "x=for 0 to 10 by 0.1\r"\
    "a=sin(x)+0.9\r"\
    "sqrt(a)=y\r\r");
  EEPROMSaveFile(
    "x = for 0 to 10 by 1\r"\
    "y = for 0 to 10 by 1\r"\
    "x*(10-x)*y*y*(10-y) = z\r\r");
  EEPROMSaveFile(
    "y = for 0 to 10 by 1\r"\
    "x = for 0 to 10 by 1");
  EEPROMSaveFile(
    "// a = 4 this line is a comment\r"\
    "a = 3 // this is a comment");
  EEPROMSaveFile(
    "x = ?[15]\r"\
    "y = ?\r"\
    "sin(x*y) = 0.5\r"\
    "x+0.5 = y\r\r");
  EEPROMSaveFile(
    "x = <-1.88722138>\r"\
    "y = <-1.38722138>\r\r");
  EEPROMSaveFile(
    "y = for 0.1, 0.5, 1.0\r"\
    "a = for 0 to 3 by 0.5\r\r");

  EEPROMSaveFile(
    "sin(x) = 2*cos(x)\r"\
    "x = ?\r\r");
  EEPROMSaveFile(
    "// a*x*x + b*x + c = 0\r"\
    "(-b + sqrt(b*b - 4*a*c))/(2*a) = ?\r"\
    "(-b - sqrt(b*b - 4*a*c))/(2*a) = ?\r"\
    "a = 1\r"\
    "b = 2\r"\
    "c = -5\r\r");
  EEPROMSaveFile(
    "sin(x) = x*x\r"\
    "z*x = y\r"\
    "cos(y)*tan(x) = 0.5\r"\
    "x = ?\r"\
    "y = ?\r"\
    "z = ?\r\r");
  EEPROMSaveFile(
    "x = ?\r"\
    "y = ?\r"\
    "sin(x*y) = 0.5\r"\
    "x+0.5 = y");
  EEPROMSaveFile(
    "y = for 0.1,0.5,0.7\r"\
    "sin(x+y) = 2*x\r"\
    "y = ?\r"\
    "x = ?\r\r");
  EEPROMSaveFile(
    "sin(x+for 0.1,0.5,0.7) = 2*x\r"\
    "x = ?\r\r");
  EEPROMSaveFile(
    "Ra=for 100,120,150,180,220,270,330,390,470,560,680,820,1000\r"\
    "Rb=for 100,150,220,330,470,680,1000\r"\
    "V=Ra/(Ra+Rb)\r\r"\
    "Ra=?\r"\
    "Rb=?\r"\
    "V=?\r\r");
  EEPROMSaveFile(
    "y = for 0.1,0.5,0.7\r"\
    "x = for 1.5 to 3 by 0.5\r"\
    "y = ?\r"\
    "x = ?\r"\
    "sin(x+y) = ?");
  EEPROMSaveFile(
    "x = for 0 to 5 by 0.1\r"\
    "sin(x) = y\r\r");
  EEPROMSaveFile(
    "b = for 0 to 0.5 by 0.1\r"\
    "x = for 0 to 5 by 0.1\r"\
    "sin(x+b) = y\r\r");
  EEPROMSaveFile(
    "y = for 0 to 10 by 0.5\r"\
    "x = for 0 to 10 by 0.5\r\r"\
    "x*(x-5)*(10-x)*y*y*(10-y) = z\r\r");
  EEPROMSaveFile(
    "u=for 0 to 2.1*pi by pi/10\r"\
    "v=for 0 to 2.1*pi by pi/10\r\r"\
    "x=cos(U)*U*(1+cos(V)/2)\r"\
    "y=sin(V)*U/2\r"\
    "z=sin(U)*U*(1+cos(V)/2)\r\r");
  EEPROMSaveFile(
    "a = for 0 to 2*pi by 0.01\r\r"\
    "sin(a*2) = y\r"\
    "cos(a*3) = x\r\r");
  EEPROMSaveFile(
    "p=for -2,-1,2,3\r"\
    "x=for -10 to 10 by 0.2\r\r"\
    "x^p=y\r");
  EEPROMSaveFile(
    "init(accuracy)=1e-9\r\r"\
    "x*x+2*x*y=33\r"\
    "y*y+x=y+15\r\r"\
    "x=?\r"\
    "y=?\r\r"\
    "init(x)=3.1\r"\
    "init(y)=4.1\r"\
    "// try using -4.1\r\r");
  EEPROMSaveFile(
    "x = for 1 to 10 by 0.01\r"\
    "y = range(1/((x-3)*(x-6)),-5,5)\r"\
    "// alternative\r"\
    "// y = 1/((x-3)*(x-6))");
}
*/

void SaveAccIter(bool commit)
{
  int16_t addr;
  int32_t iter;
  double acc;
  
  addr = EEPROMaccuracy;
  acc = EEPROMgetDbl(&addr);
  addr = EEPROMiterations;
  iter = EEPROMgetInt32(&addr);

  addr = EEPROMaccuracy;
  EEPROMsetDbl(&addr,Accuracy);
  addr = EEPROMiterations;
  EEPROMsetInt32(&addr,Iterations);

  if (((Accuracy != acc) || (Iterations != iter)) && commit)
    EEPROM.commit();
}

void ClearEEPROM()
{
  for (int16_t i = 0; i < EEPROMsize; i++)
    setEEPROM(i, 0);
  setEEPROM(0, EEPROMsignature[1]);
  setEEPROM(1, EEPROMsignature[2]);
  setEEPROM(2, EEPROMsignature[3]);
  SaveAccIter(false);
  EEPROM.commit();
}

void InitEEPROM()
{
  int16_t addr;

//  FILE *fp = fopen("EEPROM", "rb");
//  if (fp == nullptr) {
//    ClearEEPROM();
//    return;
//  }
//
//  fread(&EEPROMx,EEPROMsize, 1, fp);
//  fclose(fp);
////ClearEEPROM();

  if ((getEEPROM(0) == EEPROMsignature[1]) && (getEEPROM(1) == EEPROMsignature[2]) && (getEEPROM(2) == EEPROMsignature[3]))
  {
    addr = EEPROMaccuracy;
    Accuracy = EEPROMgetDbl(&addr);
    addr = EEPROMiterations;
    Iterations = EEPROMgetInt32(&addr);
    LoadLastFile();
  } else
    ClearEEPROM();
}
