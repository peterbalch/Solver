//==============
// Help.cpp
//==============

#include "Help.h"
#include <stdint.h>
#include "VDU.h"
#include "SimpleILI9341.h"

#define INDENT    "    "
#define TITLE     "\200"
#define COLCYAN   "\201"
#define COLWHITE  "\202"
#define WRAP      "\203"
#define TAB       "\204"
#define BRA       "\205"
#define KET       "\206"
#define CODE      "\207"

inline int imin(int a, int b) { return ((a)<(b) ? (a) : (b)); }
inline int imax(int a, int b) { return ((a)>(b) ? (a) : (b)); }

char *pg[]  = {
  /* 0 */ TITLE "Solve\r\r"\
    "Welcome to Solve - an equation solver.\r\r"\
        INDENT "Getting Started[9]\r"\
        INDENT "Samples[35]\r"\
        INDENT "Generators[3]\r"\
        INDENT "Output[4]\r"\
        INDENT "Options[5]\r"\
        INDENT "Plotting[1]\r"\
        INDENT "Syntax of Equations[22]\r"\
        INDENT "Error Messages[26]\r"\
        INDENT "Initialisation[10]\r\r"\
    "Help pages can contain numbered links shown in yellow or" WRAP\
    "cyan. Click the number key to display that page or load" WRAP\
    "the example code that follows. Click the BS key to display" WRAP\
    "the previous page.",

  /* 1 */ TITLE "Plotting\r\r"\
        INDENT "Plotting[7]\r"\
        INDENT "Line Drawing[21]\r"\
        INDENT "2D Plots[15]\r"\
        INDENT "3D Plots[16]\r"\
        INDENT "Multiple Solutions - Plotting[19]",

  /* 2 */ "", //unused

  /* 3 */ INDENT "Generators[34]\r"\
        INDENT "For Loop generators[13]\r"\
        INDENT "For Set generator[8]\r"\
        INDENT "Multiple Generators[18]\r"\
        INDENT "Order of Generators[11]\r"\
        INDENT "Generators in INITS[14]",

  /* 4 */ TITLE "Output Variables\r\r"\
        INDENT "Output Variables[6]\r"\
        INDENT "Table Display[27]\r"\
        INDENT "Table Label[17]",

  /* 5 */ TITLE "Options\r\r"\
        INDENT "System Constants[12]\r"\
        INDENT "Limits[25]\r"\
        INDENT "Error Messages[26]",

  /* 6 */ TITLE "Output Variables\r\r"\
    "In the following equations[x],\r\r"\
        CODE "x=3\r"\
        CODE "x*x=?\r"\
        CODE "x*x*x=?\r\r"\
    "the two question marks are Output variables.\r\r"\
    "When equations are being solved, an Output variable is" WRAP\
    "treated just the same as any other variable but every" WRAP\
    "Output variable counts as a different, unique variable.\r\r"\
    "In the equations above, all the 'x's refer to the same " WRAP\
    "variable but the two '?'s refer to different variables.\r\r"\
    "The first equation is solved first and the x variable is set" WRAP\
    "to 3.0. The second and third equations can then be solved " WRAP\
    "the first question mark is given the value 9.0" WRAP\
    "and the second is given the value 27.0.\r\r"\
    "Once the solver has solved as many of the equations as" WRAP\
    "it can, the values of the '?' variables are displayed." WRAP\
    "If the absolute value of an Output variable is less than" WRAP\
    "accuracy[12] then it is printed as zero.\r\r"\
    "Because Output variables are treated just the same as" WRAP\
    "other variables, it is quite permissble to embed them in" WRAP\
    "equations[x]:\r\r"\
        CODE "sin(?^2+0.1)=0.4\r\r"\
    "If there are no question marks then the x, y and z" WRAP\
    "variables act as outputs to produce a graph[7].",

  /* 7 */ TITLE "Plotting\r\r"\
    "Solve can draw 2D and 3D graphs of the solutions to" WRAP\
    "equations. For instance, the equations[x]\r\r"\
        CODE "a = for 0 to 5 by 0.1\r"\
        CODE "sin(a) =?\r"\
        CODE "a = ?\r\r"\
    "uses a For generator[13] to produce a table[27] of the" WRAP\
    "values of sin(a). If we want to plot these, we replace" WRAP\
    "the '?'[6] output variables with axis output" WRAP\
    "variables[x]:\r\r"\
        CODE "x = for 0 to 5 by 0.1\r"\
        CODE "sin(x) = y\r\r"\
    "A Plot display will appear showing the resulting graph.\r\r"\
    "Solve can display 2D Plots[15] and 3D Plots[16].",

  /* 8 */ TITLE "Set Generators\r\r"\
    "What if we want to solve an equation like\r\r"\
        CODE "sin(x+y) = 2*x\r\r"\
    "for various values of y, say 0.1, 0.5 and 1.0?\r\r"\
    "Solve allows you to set a variable to a sequence of" WRAP\
    "values[x]:\r\r"\
        CODE "y = for 0.1, 0.5, 1.0\r"\
        CODE "sin(x+y) = 2*x\r"\
        CODE "x = ?\r\r"\
    "The values after the FOR are called a 'Set'. The" WRAP\
    "equations are solved with y equal to 0.1 and the" WRAP\
    "answers are displayed. Then they are solved with y" WRAP\
    "set equal to 0.5 and the new answers displayed." WRAP\
    "Finally, they are solved with y=1.0.\r\r"\
    "All three sets of answers cannot be displayed at the" WRAP\
    "same time in the Equation Display so a Table[27] is" WRAP\
    "displayed.\r\r"\
    "A Set generator (or any other generator) is treated as a" WRAP\
    "variable with a known value and can appear anywhere" WRAP\
    "that a variable can[x]:\r\r"\
        CODE "sin(x+ for 0.1,0.5,0.7) = 2*x\r"\
        CODE "x = ?\r\r"\
    "A For generator[13] can be used instead of a Set generator" WRAP\
    "where a set of equally spaced values is required.\r\r"\
    "When a list of equations contains more than one" WRAP\
    "generator, the order[11] in which generators are" WRAP\
    "executed becomes important.\r\r"\
    "When an equation has several solutions, a generator can" WRAP\
    "be used with an INIT[10] to generate a set of initialisation" WRAP\
    "values[14]. You can use Plots[7] to find the approximate" WRAP\
    "locations[19] of the solutions.",

  /* 9 */ TITLE "Getting Started\r\r"\
    "The main display of Solve is the Equation Editor[23].\r\r"\
    "Type the following equations[22] into the Equation Editor[x].\r\r"\
        CODE "5*x-x*x-6 = 0\r"\
        CODE "x=?\r\r"\
    "Use the fn key to select between character sets.\r\r"\
    "Each equation must be on a separate line.\r\r"\
    "Now click the Solve button[28].\r\r"\
    "The display should change to\r\r"\
        CODE "5*x-x*x-6 = 0\r"\
        CODE "x=<2>\r\r"\
    "Solve has found a value for x which satisfies the first" WRAP\
    "equation. The ? in the second equation has been replaced" WRAP\
    "by the answer: <2>.",

  /* 10 */ TITLE "Initialisation\r\r"\
    "The following equations have two sets of solutions:\r\r"\
        CODE "x*x = 2*x + 15\r"\
        CODE "x= ?\r\r"\
    "They are\r\r"\
        CODE "x=<-3.24264068>\r\r"\
    "and\r\r"\
        CODE "x=<5.242640687>\r\r"\
    "The solution which the solver finds depends on its initial" WRAP\
    "guess of the value of x.\r\r"\
    "The solver generates its first initial guess for x which is" WRAP\
    "usually 1.0. If this guess does not lead to a solution then" WRAP\
    "the solver generates a succession of initial guesses until" WRAP\
    "either one leads to a solution or the solver gives up" WRAP\
    "completely.\r\r"\
    "The initial guesses form the sequence:\r\r"\
        INDENT "-1" TAB"g'+'negate\r"\
        INDENT "-2" TAB"g'+'reciprocal and double\r"\
        INDENT "2" TAB"g'+'negate\r"\
        INDENT "0.5" TAB"g'+'reciprocal\r"\
        INDENT "-0.5" TAB"g'+'negate\r"\
        INDENT "-4" TAB"g'+'reciprocal and double\r"\
        INDENT "4" TAB"g'+'negate\r"\
        INDENT "0.25" TAB"g'+'reciprocal\r"\
        INDENT "-0.25" TAB"g'+'negate\r"\
        INDENT "-8" TAB"g'+'reciprocal and double\r"\
        INDENT "8" TAB"g'+'negate\r"\
        INDENT "...\r\r"\
    "These are alternately positive and negative and alternately" WRAP\
    "get larger and smaller.\r\r"\
    "In the example above, the initial guess of 1.0 leads to the" WRAP\
    "solution:\r\r"\
        CODE "x=<-3.24264068>\r\r"\
    "and the solver stops.\r\r"\
    "To find the other solution, we must force the solver to" WRAP\
    "use an initial guess somewhere near 5. We do so by" WRAP\
    "adding the line:\r\r"\
        CODE "init(x) = 5\r\r"\
    "The solver now finds the answer:\r\r"\
        CODE "x=<5.242640687>\r\r"\
    "The solver makes two passes through the equations. On" WRAP\
    "the first pass, it solves all the equations with an INIT in" WRAP\
    "them. On the second pass, it solves the remaining" WRAP\
    "equations and uses the initialisation values as the initial" WRAP\
    "guesses for the variables .\r\r"\
    "If the solver cannot find a solution using the initialisation" WRAP\
    "value for a variable then it reverts to the sequence of" WRAP\
    "guesses described above.\r\r"\
    "When an equation has several solutions, a generator[34] can" WRAP\
    "be used with an INIT to generate a set of initialisation" WRAP\
    "values[14].\r\r"\
    "Non-linear simultaneous equations can have several " WRAP\
    "solutions, for instance, solving[x]:\r\r"\
        CODE "x*x+2*x*y=32\r"\
        CODE "y*y+x=y+15\r"\
        CODE "x=?\r"\
        CODE "y=?\r\r"\
    "gives just one of the solutions\r\r"\
        CODE "x=<2.923603392>\r"\
        CODE "y=<4.010896838>\r\r"\
    "to find the other three, you must set various INITs, setting[x]\r\r"\
        CODE "init(x)=-14\r"\
        CODE "init(y)=6\r\r"\
    "gives\r\r"\
        CODE "x=<-14.1047439>\r"\
        CODE "y=<5.918001837>\r\r"\
    "or setting[x]\r\r"\
        CODE "init(x)=-3\r"\
        CODE "init(y)=-4\r\r"\
    "gives\r\r"\
        CODE "x=<-3.02577347>\r"\
        CODE "y=<-3.77501736>\r\r"\
    "or setting[x]\r\r"\
        CODE "init(x)=8\r"\
        CODE "init(y)=-2\r\r"\
    "gives\r\r"\
        CODE "x=<8.206913995>\r"\
        CODE "y=<-2.15388130>\r\r"\
    "When there are two unknowns, you can use Plots[7] to" WRAP\
    "find the approximate locations[20] of solutions and use these" WRAP\
    "for initialisation. But with three or more unknowns, it's" WRAP\
    "more difficult.",

  /* 11 */ TITLE "Order of Generators\r\r"\
    "The following example has two generators and two" WRAP\
    "simultaneous equations[x]:\r\r"\
        CODE "a = for -2 to 1 by 1\r"\
        CODE "b = for 1 to 3 by 1\r"\
        CODE "x*x+a=0\r"\
        CODE "y*y+b=5\r"\
        CODE "a=?\r"\
        CODE "b=?\r"\
        CODE "x=?\r"\
        CODE "y=?\r\r"\
    "It produces the following answers\r\r"\
        CODE "a" TAB"g" "b" TAB"j" "x" TAB"p" "y\r"\
        CODE "-2" TAB"g" "1" TAB"j" "1.41421356" TAB"p" "2\r"\
        CODE "-2" TAB"g" "2" TAB"j" "1.41421356" TAB"p" "1.73205080\r"\
        CODE "-2" TAB"g" "3" TAB"j" "1.41421356" TAB"p" "1.41421356\r"\
        "\r"\
        CODE "-1" TAB"g" "1" TAB"j" "1" TAB"p" "2\r"\
        CODE "-1" TAB"g" "2" TAB"j" "1" TAB"p" "1.73205080\r"\
        CODE "-1" TAB"g" "3" TAB"j" "1" TAB"p" "1.41421356\r"\
        "\r"\
        CODE "0" TAB"g" "1" TAB"j" "0" TAB"p" "2\r"\
        CODE "0" TAB"g" "2" TAB"j" "0" TAB"p" "1.73205080\r"\
        CODE "0" TAB"g" "3" TAB"j" "0" TAB"p" "1.41421356\r"\
        "\r"\
        CODE "1" TAB"g" "1" TAB"j" "   ?" TAB"p" "2\r"\
        CODE "1" TAB"g" "2" TAB"j" "   ?" TAB"p" "1.73205080\r"\
        CODE "1" TAB"g" "3" TAB"j" "   ?" TAB"p" "1.41421356\r\r"\
    "Solve has displayed a ? where it has been unable to find" WRAP\
    "a solution.\r\r"\
    "Note that the a generator generates its first value then b" WRAP\
    "cycles through all its values; the a generator then" WRAP\
    "generates its second value and b cycles through all its" WRAP\
    "values again, and so on.\r\r"\
    "In general, later generators in the equation list cycle faster" WRAP\
    "than earlier ones.\r\r"\
    "So in this eaxmple, r cycles fastest, then q then p[x].\r\r"\
        CODE "p = for 1 to 2 by 1\r"\
        CODE "q = for 1,10,100\r"\
        CODE "r = for 7 to 6 by -1\r"\
        CODE "p=?\r"\
        CODE "q=?\r"\
        CODE "r=?\r\r"\
    "gives\r\r"\
        CODE "p" TAB"g" "q" TAB"l" "r\r"\
        CODE "1" TAB"g" "1" TAB"l" "7\r"\
        CODE "1" TAB"g" "1" TAB"l" "6\r"\
        "\r"\
        CODE "1" TAB"g" "10" TAB"l" "7\r"\
        CODE "1" TAB"g" "10" TAB"l" "6\r"\
        "\r"\
        CODE "1" TAB"g" "100" TAB"l" "7\r"\
        CODE "1" TAB"g" "100" TAB"l" "6\r"\
        "\r"\
        "\r"\
        CODE "2" TAB"g" "1" TAB"l" "7\r"\
        CODE "2" TAB"g" "1" TAB"l" "6\r"\
        "\r"\
        CODE "2" TAB"g" "10" TAB"l" "7\r"\
        CODE "2" TAB"g" "10" TAB"l" "6\r"\
        "\r"\
        CODE "2" TAB"g" "100" TAB"l" "7\r"\
        CODE "2" TAB"g" "100" TAB"l" "6",

  /* 12 */ TITLE "System Constants\r\r"\
    "The following system constants can be set:\r\r"\
        CODE "init( iterations ) = expression\r"\
        CODE "init( accuracy ) = expression\r\r"\
    "Solve will stop looking for solution to an equation when" WRAP\
    "the equation equates to within 'Accuracy' or if it has not" WRAP\
    "found the solution after 'Iterations' attempts.\r\r"\
    "These setting will be assigned the new values after the" WRAP\
    "equations have been solved. They will be stored and used " WRAP\
    "from then on.\r\r"\
    "The default values are:\r\r"\
        CODE "init( iterations ) = 100\r"\
        CODE "init( accuracy ) = 1e-9\r\r"\
    "Iterations and Accuracy are not used when the equation" WRAP\
    "is solved using the direct or Gaussian elimination" WRAP\
    "methods[28]",

  /* 13 */ TITLE "For generators\r\r"\
    "A set of equally spaced values will be generated by a For" WRAP\
    "generator[x]\r\r"\
        CODE "a = for 0 to 3 by 0.5\r"\
        CODE "a = ?\r"\
        CODE "b = a*a\r"\
        CODE "b = ?\r\r"\
    "The equations are solved with 'a' set equal to 0. Then" WRAP\
    "they are solved with 'a=0.5', then with 'a=1' and so on until" WRAP\
    "'a=3'. The Table[27] will show:\r\r"\
        CODE "a" TAB"g" "b\r"\
        CODE "0" TAB"g" "0\r"\
        CODE "0.5" TAB"g" "0.25\r"\
        CODE "1" TAB"g" "1\r"\
        CODE "1.5" TAB"g" "2.25\r"\
        CODE "2" TAB"g" "4\r"\
        CODE "2.5" TAB"g" "6.25\r"\
        CODE "3" TAB"g" "9\r\r"\
    "For generators can have either positive or negative BY" WRAP\
    "expressions:\r\r"\
        CODE "x = for 50 to 1 by -1\r\r"\
    "The three expressions for the 'from', TO and BY parts of" WRAP\
    "the For generator must all be constants; they may not" WRAP\
    "contain variables or other generators.\r\r"\
    "A For generator always generates at least one value, for" WRAP\
    "instance:\r\r"\
        CODE "a = for 5 to 1 by 1\r\r"\
    "generates the value 5 then stops.\r\r"\
    "A Set generator[8] can be used instead of a For generator" WRAP\
    "where the values generated should not be equally spaced .\r\r"\
    "When a list of equations contains more than one" WRAP\
    "generator, the order[11] in which generators are executed" WRAP\
    "becomes important.\r\r"\
    "When an equation has several solutions, a generator can" WRAP\
    "be used with an INIT[10] to generate a set of initialisation" WRAP\
    "values[14]. You can use Plots[7] to find the approximate" WRAP\
    "locations[19] of the solutions.",

  /* 14 */ TITLE "Generators in INITS\r\r"\
    "An equation such as\r\r"\
        CODE "sin(x)-0.5=0\r\r"\
    "has an infinite number of solutions. For instance, there are" WRAP\
    "solutions to sin(x)-0.5=0 near to x=0.5, x=2.6, x=6.8 and" WRAP\
    "x=8.9.\r\r"\
    "To find the exact value of the solution near x=0.5, we" WRAP\
    "could use an INIT[10]:\r\r"\
        CODE "init(x)=0.5\r\r"\
    "and we would get the answer\r\r"\
        CODE "x=<0.523598775>\r\r"\
    "to find all of the solutions between x=0 and x=10, we" WRAP\
    "could use an INIT[10] and a generator[x]:\r\r"\
        CODE "sin(x)-0.5=0\r"\
        CODE "x= ?\r"\
        CODE "init(x)=for 0 to 10 by 1\r\r"\
    "which gives the answer table\r\r"\
        INDENT "x\r"\
        INDENT "0.523598775\r"\
        INDENT "0.523598775\r"\
        INDENT "2.617993878\r"\
        INDENT "2.617993878\r"\
        INDENT "2.617993878\r"\
        INDENT "6.806784082\r"\
        INDENT "6.806784082\r"\
        INDENT "6.806784082\r"\
        INDENT "8.901179185\r"\
        INDENT "8.901179185\r"\
        INDENT "8.901179185\r\r"\
    "You can use Plots[7] to find the approximate locations[19] of" WRAP\
    "solutions and use these for initialisation.",

  /* 15 */ TITLE "2D Plots\r\r"\
    "In a list of equations such as[x]:\r\r"\
        CODE "x = for 0 to 5 by 0.1\r"\
        CODE "sin(x) = y\r\r"\
    "Because there are no question marks, x and y variables" WRAP\
    "act as output variables[6] and a plot is drawn.\r\r"\
    "Multiple generators can be used to give nested plots[18]." WRAP\
    "When multiple generators are used, the order of the" WRAP\
    "generators controls the connectivity[21] of the graphs.\r\r"\
    "A graph will show a broken line when no solution could be" WRAP\
    "found.\r\r"\
    "The axes of graphs are labelled[17] according to the" WRAP\
    "equations which contain the output variable.",

  /* 16 */ TITLE "3D Plots\r\r"\
    "If a plot has three axes, x, y and z[x]:\r\r"\
        CODE "x = for 0 to 10 by 1\r"\
        CODE "y = for 0 to 10 by 1\r"\
        CODE "x*(10-x)*y*y*(10-y) = z\r\r"\
    "then a 3D graph will be displayed.\r\r"\
    "The arrow keys[23] control the rotation of the graph.\r\r"\
    "The number of points stored is limited to 1000.\r\r"\
    "The order[11] of generators[34] controls how the points of a" WRAP\
    "graph are connected.",

  /* 17 */ TITLE "Table and Plot Labels\r\r"\
    "The columns of the Table[27] and the axes of Plots[7] are" WRAP\
    "labelled according to the equations which contain the output" WRAP\
    "variable. For instance, the equations[x]\r\r"\
        CODE "? = resistance\r\r"\
        CODE "voltage/time = ?\r\r"\
    "will label the columns\r\r"\
        CODE "resistance" TAB"g" "voltage/time\r\r"\
    "The equation is split into two parts by the '=' character;" WRAP\
    "one part contains the output variable and the other part" WRAP\
    "doesn't. The column label is the part which does not" WRAP\
    "contain the output variable.\r\r"\
    "So that[x]\r\r"\
        CODE "x=2*sin(?)\r\r"\
    "gives the column label\r\r"\
        INDENT "x",

  /* 18 */ TITLE "Multiple Generators in Plots\r\r"\
    "Multiple generators[34] can be used to give nested plots. For" WRAP\
    "instance[x]:\r\r"\
        CODE "p=for -2,-1,2,3\r"\
        CODE "x=for -10 to 10 by 0.2\r"\
        CODE "x^p=y\r\r"\
    "displays the plots of 1/(x^2), 1/x, x^2 and x^3.\r\r"\
    "When a list of equations contains more than one" WRAP\
    "generator, the order[11] in which generators are executed" WRAP\
    "becomes important.",

  /* 19 */ TITLE "Find Multiple Solutions with Plots\r\r"\
    "The following equations have two sets of solutions[x]:\r\r"\
        CODE "x*x = 2*x + 17\r"\
        CODE "x= ?\r\r"\
    "They are:\r\r"\
        CODE "x=<5.242640687>\r"\
        CODE "x=<-3.24264068>\r\r"\
    "We can persuade Solve to find these solutions by using" WRAP\
    "INITs[10]:\r\r"\
        CODE "init(x)=5\r"\
        "gives\r"\
        CODE "x=<5.242640687>\r\r"\
    "and\r"\
        CODE "init(x)=-3\r"\
    "gives\r"\
        CODE "x=<-3.24264068>\r\r"\
    "But how do we know how many solutions there are and" WRAP\
    "what initial value to give x? The best way is to plot[7] x" WRAP\
    "against the difference between the left and right sides of" WRAP\
    "the equation.\r\r"\
    "Just add a 'y' term to one side of the equation and have" WRAP\
    "a generator[34] for the 'x' term[x].\r\r"\
        CODE "x*x = 2*x + 16 +y\r"\
        CODE "x = for -10 to 10 by 1\r\r"\
    "Look where the graph crosses the x-axis. I got 5 and -3\r"\
    "So there are solutions near to 5 and -3; use these values" WRAP\
    "as initialisations[10] in your original equation.\r\r"\
    "When an equation has several solutions[19], the technique is" WRAP\
    "slightly different.",

  /* 20 */ TITLE "Multiple Solutions to Equations\r\r"\
    "In the earlier section on simultaneous equations we saw" WRAP\
    "that[x]\r\r"\
        CODE "x*x+2*x*y=32\r"\
        CODE "y*y+x=y+15\r"\
        CODE "x= ?\r"\
        CODE "y=?\r\r"\
    "can have several solutions. We can find approximately" WRAP\
    "where they are by plotting[7] the variables for each graph" WRAP\
    "against each other.\r\r"\
    "To plot the graph for one equation, we can use a" WRAP\
    "generator[34] to produce values for one unknown and plot" WRAP\
    "this against the value that Solve finds for the other" WRAP\
    "unknown.\r\r"\
    "If we do this for both graphs, we can see that the" WRAP\
    "solutions will be where the two graphs cross.\r\r"\
    "Those approximate values can be used as initial values[10]" WRAP\
    "in our original equations.",

  /* 21 */ TITLE "When are Lines Drawn\r\r"\
    "When you use multiple generators[34], the order of the" WRAP\
    "generators is important. Lets say we wanted a plot of a" WRAP\
    "against sin(a+b) for increasing values of b[x].\r\r"\
        CODE "x = for 0 to 5 by 0.1\r"\
        CODE "b = for 0 to 0.5 by 0.1\r"\
        CODE "sin(x+b) = y\r\r"\
    "We would expect to get a set of sine waves each offset" WRAP\
    "from the next. Instead, we get lots of short vertical lines.\r\r"\
    "We got the order of the generators wrong, what we" WRAP\
    "should have written is[x]:\r\r"\
        CODE "b = for 0 to 0.5 by 0.1\r"\
        CODE "x = for 0 to 5 by 0.1\r"\
        CODE "sin(x+b) = y\r\r"\
    "How do we know in what order to write the generators?" WRAP\
    "Roughly speaking, the lines will be joined according to the" WRAP\
    "last generator in the equation list.\r\r"\
    "Imagine that the plotter has a pen. When the equations for" WRAP\
    "a graph are first solved, the pen moves to those" WRAP\
    "coordinates and the pen is put down on the paper.\r\r"\
    "Each time the equations are solved again, the pen moves" WRAP\
    "in a straight line to the next coordinates then the pen is" WRAP\
    "put down - if the pen was already down then it draws a" WRAP\
    "line.\r\r"\
    "If any generator finishes its sequence of numbers then the" WRAP\
    "pen is lifted and the next movement of the pen will not" WRAP\
    "draw a line.\r\r"\
    "As a very simple example, consider[x]\r\r"\
        CODE "q=for 1 to 10 by 4\r"\
        CODE "p=for 1 to 3 by 1\r"\
        CODE "p+q=x\r"\
        CODE "1=y\r\r"\
    "The pen has been lifted each time the p generator finished" WRAP\
    "its FOR loop.\r\r"\
    "If the solver fails to find a solution for the equations then" WRAP\
    "the pen is lifted and there will be a gap in the graph. For" WRAP\
    "instance[x]\r\r"\
        CODE "x=for 0 to 10 by 0.1\r"\
        CODE "a=sin(x)+0.9\r"\
        CODE "sqrt(a)=y\r\r"\
    "The solver is unable to find solutions when y is negative" WRAP\
    "so the graph has gaps where no solution was found.\r\r"\
    "In a 3D plot[16], the order of generators controls how the" WRAP\
    "points of a graph are connected. If we swap the order of" WRAP\
    "the generators in this example, the lines of the graph run" WRAP\
    "parallel to either the x-axis or the y-axis[x]:\r\r"\
        CODE "x = for 0 to 10 by 1\r"\
        CODE "y = for 0 to 10 by 1\r"\
        CODE "x*(10-x)*y*y*(10-y) = z\r\r"\
    "But swapping the order of the generators gives[x].\r\r"\
        CODE "y = for 0 to 10 by 1\r"\
        CODE "x = for 0 to 10 by 1",

  /* 22 */ TITLE "Syntax of Equations\r\r"\
    "The following meta-symbols are used:\r\r"\
        INDENT "::= " TAB"h" "may be replaced by\r"\
        INDENT "|" TAB"h" "or\r"\
        INDENT "{ ... }" TAB"h" "optional\r"\
        INDENT BRA " ... " KET TAB"h" "zero or more occurrences of\r"\
        INDENT "( ... )" TAB"h" "grouping\r\r"\
    "in this specification of the syntax of equations:\r\r"\
        INDENT "equation ::= " TAB"h" "expr = expr\r\r"\
        INDENT "expr ::= " TAB"h" "{ - } term ' BRA ' ( + | - ) term " KET "\r\r"\
        INDENT "term ::= " TAB"h" "power ' BRA ' ( * | / | \\ ) power " KET "\r\r"\
        INDENT "power ::= " TAB"h" "factor ' BRA ' ^ factor " KET "\r\r"\
        INDENT "factor ::= " TAB"h" "variable\r"\
        INDENT TAB"g" "|  number\r"\
        INDENT TAB"g" "|  ?[6]\r"\
        INDENT TAB"g" "|  functionCall\r"\
        INDENT TAB"g" "|  ( expr )\r"\
        INDENT TAB"g" "|  generator\r"\
        INDENT TAB"g" "|  IF expr THEN expr ELSE expr\r"\
        INDENT TAB"g" "|  INIT[10] ( variable )\r"\
        INDENT TAB"g" "|  ITERATIONS[12]\r"\
        INDENT TAB"g" "|  ACCURACY[12]\r\r"\
        INDENT "number ::= " TAB"h" "digits { . { digits } }\r"\
        INDENT TAB"g" "|  digits { . { digits } { E { + | - } digits}\r\r"\
        INDENT "generator ::= " TAB"h" "FOR const TO const BY const[13]\r"\
        INDENT TAB"g" "|  FOR constant ' BRA ' , constant " KET "[8]\r\r"\
        INDENT "functionCall ::= " TAB"h" "funcname[31] ( expr )\r"\
        INDENT TAB"g" "|  PI\r"\
        INDENT TAB"g" "|  ( MIN | MAX ) ( expr ' BRA ' , expr " KET " )\r\r"\
        INDENT "funcName ::= " TAB"h" "SIN | COS | TAN\r"\
        INDENT TAB"g" "|  ARCSIN | ARCCOS | ARCTAN\r"\
        INDENT TAB"g" "|  DEG | RAD\r"\
        INDENT TAB"g" "|  LN | LOG | EXP\r"\
        INDENT TAB"g" "|  SQRT\r\r"\
        INDENT "variable[30] ::= " TAB"h" "( A..Z ) ' BRA ' A..Z | 0..9 " KET "\r\r"\
    "Only the first 10 characters of variable names are" WRAP\
    "significant.\r\r"\
    "A constant is an expression containing only numbers," WRAP\
    "operators and function calls.\r\r"\
    "Characters in comments[32] are ignored.",

  /* 23 */ TITLE "Editing Keys\r\r"\
    "The following key commands operate in the Equation" WRAP\
    "display:\r\r"\
        INDENT "CR" TAB"g" "Inserts a line\r"\
        INDENT "SP" TAB"g" "Inserts a space\r"\
        INDENT "BS" TAB"g" "Deletes the character before the cursor\r"\
        INDENT "Arrows" TAB"g" "Moves the cursor up/down/left/right\r"\
        INDENT "fn" TAB"g" "Selects the alternative character set\r"\
        INDENT "SOLVE" TAB"g" "Executes the equation solver\r\r"\
    "The following key commands operate in the Table[27]" WRAP\
    "display:\r\r"\
        INDENT "Arrows" TAB"g" "Moves the table up/down/left/right\r"\
        INDENT "SOLVE" TAB"g" "Switches to the equations display\r\r"\
    "The following key commands operate in the 3D Plot[16]" WRAP\
    "display:\r\r"\
        INDENT "Arrows" TAB"g" "Rotates the plot up/down/left/right\r"\
        INDENT "SOLVE" TAB"g" "Switches to the equations display\r\r"\
    "In the Equation display, holding down a key selects special" WRAP\
    "commands:\r\r"\
        INDENT "?" TAB"g" "Display Help pages\r"\
        INDENT "BS" TAB"g" "Clear the whole equations screen\r"\
        INDENT "CR" TAB"g" "Duplicate current line\r"\
        INDENT "SP" TAB"g" "delete current line\r"\
        INDENT "Left" TAB"g" "Load previous saved file[24]\r"\
        INDENT "Right" TAB"g" "Load next saved file[24]",

  /* 24 */ TITLE "Files\r\r"\
    "When you click the Solve button the equations are saved" WRAP\
    "to long-term storage. (Duplicate files are not saved.)\r\r"\
    "Several files can be saved. The values of accuracy[12] and" WRAP\
    "Iterations[12] are also stored.\r\r"\
    "To reload the previous version of the equations, hold down" WRAP\
    "the left-arrow key[23]. You can use this as an \"undo\"" WRAP\
    "command.\r\r"\
    "To reload the next version of the equations, hold down the" WRAP\
    "right-arrow key.\r\r"\
    "When the calculator is switched on, the latest version of" WRAP\
    "the equations is loaded.\r\r"\
    "The total file space is 4096 bytes.",

  /* 25 */ TITLE "Limits\r\r"\
    "There is an overall limit of 20 equations.\r\r"\
    "Solve cannot create an Equation file with more than 50" WRAP\
    "lines. Each equation line must contain no more than 100" WRAP\
    "characters.\r\r"\
    "The number of points used to redraw the Plot[7] is limited" WRAP\
    "to 1000.\r\r"\
    "The total file space[24] is 4096 bytes.",

  /* 26 */ TITLE "Error Messages\r\r"\
    "Solve reports the following errors when it is parsing the" WRAP\
    "equations:\r\r"\
        INDENT "Line too long\r"\
        INDENT "Too many equations\r"\
        INDENT "Syntax error: The equation does not make sense\r\r"\
    "There is an overall limit of 50 equations.\r\r"\
    "Each equation line must contain fewer than 80 characters.\r\r"\
    "Solve reports the following errors when it is solving the" WRAP\
    "equations:\r\r"\
        INDENT "Unresolvable inequality\r"\
        INDENT "Memory overflow: equations are too complicated\r\r"\
    "An \"Unresolvable inequality\"  occurs when there are more" WRAP\
    "equations than unknowns, for instance[x]\r\r"\
        CODE "x*x=5\r"\
        CODE "x*x*x=7\r"\
        CODE "x = ?",

  /* 27 */ TITLE "Table Display\r\r"\
    "When a generator[34] is used, several answers will be" WRAP\
    "found. All the answers cannot be displayed at the same" WRAP\
    "time in the Equation display so a Table is displayed.\r\r"\
    "The Solve button changes back to the Equation display.\r\r"\
    "The columns of the tables are labelled[17] according to the" WRAP\
    "equations which contain the output variable.",

  /* 28 */ TITLE "Solve Command\r\r"\
    "The Solve command attempts to find solutions to the" WRAP\
    "equations in the Equation Editor display. The solutions are" WRAP\
    "presented in the Equation Editor, the Table display[27] or the" WRAP\
    "Plot display[7].\r\r"\
    "Solve can solve some equations directly but for others, it" WRAP\
    "must search for a solution. It searches using various" WRAP\
    "methods\r\r"\
        INDENT "Newton-Raphson\r"\
        INDENT "Secant\r"\
        INDENT "Regula-Falsi\r"\
        INDENT "Bisection\r\r"\
    "With Simultaneous Equations[33], it uses\r"\
        INDENT "Newton-Raphson\r"\
        INDENT "Gaussian elimination",

  /* 29 */ "", //unused

  /* 30 */ TITLE "Variable Names\r\r"\
    "Variable names consist of a letter followed by zero or" WRAP\
    "more letters or numbers. Only the first 10 characters are" WRAP\
    "significant.\r\r"\
        INDENT "thisisalongname\r\r"\
    "is the same as\r\r"\
        INDENT "thisisalon",

  /* 31 */ TITLE "Function Names\r\r"\
    "The following functions are available:\r\r"\
        INDENT COLCYAN "sin(expr) " COLWHITE TAB"h" "sine: argument in radians\r"\
        INDENT COLCYAN "cos(expr) " COLWHITE TAB"h" "cosine: argument in radians\r"\
        INDENT COLCYAN "tan(expr) " COLWHITE TAB"h" "tangent: argument in radians\r"\
        INDENT COLCYAN "arcsin(expr) " COLWHITE TAB"h" "arcsine: result in radians\r"\
        INDENT COLCYAN "arccos(expr) " COLWHITE TAB"h" "arccosine: result in radians\r"\
        INDENT COLCYAN "arctan(expr) " COLWHITE TAB"h" "arctangent: result in radians\r"\
        INDENT COLCYAN "deg(expr) " COLWHITE TAB"h" "argument in radians, result in degrees\r"\
        INDENT COLCYAN "rad(expr) " COLWHITE TAB"h" "argument in degrees, result in radians\r"\
        INDENT COLCYAN "ln(expr) " COLWHITE TAB"h" "natural logarithm\r"\
        INDENT COLCYAN "exp(expr) " COLWHITE TAB"h" "exponentiation\r"\
        INDENT COLCYAN "log(expr) " COLWHITE TAB"h" "logarithm to base 10\r"\
        INDENT COLCYAN "sqrt(expr) " COLWHITE TAB"h" "square root\r"\
        INDENT COLCYAN "max(expr,expr, ...) " COLWHITE TAB"h" "maximum\r"\
        INDENT COLCYAN "min(expr,expr, ...) " COLWHITE TAB"h" "minimum\r"\
        INDENT COLCYAN "pi " COLWHITE TAB"h" "pi\r"\
        INDENT COLCYAN "if exprA then exprB else exprC\r"\
        INDENT TAB"h" "if exprA < 0 then exprB else exprC",

  /* 32 */ TITLE "Comments\r\r"\
    "When the equations[22] are being parsed, blank characters" WRAP\
    "and comments are ignored. Blank lines are also ignored.\r\r"\
    "A comment starts with with // characters and continues to" WRAP\
    "the end of the line.\r\r"\
        CODE "// a = 4 this line is a comment\r"\
        CODE "a = 3 // this is a comment",

  /* 33 */ TITLE "Simultaneous Equations\r\r"\
    "In this example, none of the equations contain only a single" WRAP\
    "unknown[x]:\r\r"\
        CODE "x = ?\r"\
        CODE "y = ?\r"\
        CODE "sin(x*y) = 0.5\r"\
        CODE "x+0.5 = y\r\r"\
    "The solver treats all the equations as a set of" WRAP\
    "simultaneous equations and solves them as a group. There" WRAP\
    "are an infinite number of answers; the ones it finds are:\r\r"\
        CODE "x = <-1.88722138>\r"\
        CODE "y = <-1.38722138>\r\r"\
    "The solver is much slower at solving simultaneous" WRAP\
    "equations and the methods it can use are more limited.",

  /* 34 */ TITLE "Generators\r\r"\
    "Solve allows you to set a variable to a sequence of" WRAP\
    "values, for instance:\r\r"\
        CODE "y = for 0.1, 0.5, 1.0\r"\
        CODE "a = for 0 to 3 by 0.5\r\r"\
    "'y' is set to the values '0.1', '0.5' and '1.0' using a Set" WRAP\
    "generator[8].\r\r"\
    "'a' is set to '0.0', '0.5', '1.0' ... '3.0' using a For generator[13].\r\r"\
    "At each step the the other equations in the equation list" WRAP\
    "are solved. The results can be displayed as a plot[7] or a" WRAP\
    "Table[27] is display.\r\r"\
    "When a list of equations contains more than one" WRAP\
    "generator, the order[11] in which generators are executed" WRAP\
    "becomes important.",

  /* 35 */ TITLE "Samples\r\r"\
        INDENT "Sample Equations[36]\r"\
        INDENT "Sample Plotting[38]\r"\
        INDENT "Accuracy, init and Range[39]",

  /* 36 */ TITLE "Sample Equations\r\r"\
    "Single Variable[x]\r"\
      CODE "sin(x) = 2*cos(x)\r"\
      CODE "x = ?\r\r"\

    "Quadratic[x]\r"\
      CODE "// a*x*x + b*x + c = 0\r"\
      CODE "(-b + sqrt(b*b - 4*a*c))/(2*a) = ?\r"\
      CODE "(-b - sqrt(b*b - 4*a*c))/(2*a) = ?\r"\
      CODE "a = 1\r"\
      CODE "b = 2\r"\
      CODE "c = -5\r\r"\

    "Multiple[x]\r"\
      CODE "sin(x) = x*x\r"\
      CODE "z*x = y\r"\
      CODE "cos(y)*tan(x) = 0.5\r"\
      CODE "x = ?\r"\
      CODE "y = ?\r"\
      CODE "z = ?\r\r"\

    "Simultaneous[x]\r"\
      CODE "x = ?\r"\
      CODE "y = ?\r"\
      CODE "sin(x*y) = 0.5\r"\
      CODE "x+0.5 = y",

  /* 37 */ TITLE "Sample Generators\r\r"\
    "For and table[x]\r"\
      CODE "y = for 0.1,0.5,0.7\r"\
      CODE "sin(x+y) = 2*x\r"\
      CODE "y = ?\r"\
      CODE "x = ?\r\r"\

    "Set and table[x]\r"\
      CODE "sin(x+for 0.1,0.5,0.7) = 2*x\r"\
      CODE "x = ?\r\r"\

    "Set and table[x]\r"\
      CODE "ra=for 100,120,150,180,220,270,330,390,470,560,680,820,1000\r"\
      CODE "rb=for 100,150,220,330,470,680,1000\r"\
      CODE "V=ra/(ra+rb)\r\r"\
      CODE "ra=?\r"\
      CODE "rb=?\r"\
      CODE "V=?\r\r"\

    "For, set and table[x]\r"\
      CODE "y = for 0.1,0.5,0.7\r"\
      CODE "x = for 1.5 to 3 by 0.5\r"\
      CODE "y = ?\r"\
      CODE "x = ?\r"\
      CODE "sin(x+y) = ?",

  /* 38 */ TITLE "Sample Plotting\r\r"\
    "2D plot[x]\r"\
      CODE "x = for 0 to 5 by 0.1\r"\
      CODE "sin(x) = y\r\r"\

    "2D plot multi-lines[x]\r"\
      CODE "b = for 0 to 0.5 by 0.1\r"\
      CODE "x = for 0 to 5 by 0.1\r"\
      CODE "sin(x+b) = y\r\r"\

    "3D plot[x]\r"\
      CODE "y = for 0 to 10 by 0.5\r"\
      CODE "x = for 0 to 10 by 0.5\r\r"\
      CODE "x*(x-5)*(10-x)*y*y*(10-y) = z\r\r"\

    "3D shape[x]\r"\
      CODE "u=for 0 to 2.1*pi by pi/10\r"\
      CODE "v=for 0 to 2.1*pi by pi/10\r\r"\
      CODE "x=cos(U)*U*(1+cos(V)/2)\r"\
      CODE "y=sin(V)*U/2\r"\
      CODE "z=sin(U)*U*(1+cos(V)/2)\r\r"\

    "2D lisajous[x]\r"\
      CODE "a = for 0 to 2*pi by 0.01\r\r"\
      CODE "sin(a*2) = y\r"\
      CODE "cos(a*3) = x\r\r"\

    "2D powers[x]\r"\
      CODE "p=for -2,-1,2,3\r"\
      CODE "x=for -10 to 10 by 0.2\r\r"\
      CODE "x^p=y\r",

  /* 39 */ TITLE "Accuracy, init and Range\r"\
    "Accuracy and init[x]\r"\
      CODE "accuracy=1e-9\r\r"\
      CODE "x*x+2*x*y=33\r"\
      CODE "y*y+x=y+15\r\r"\
      CODE "x=?\r"\
      CODE "y=?\r\r"\
      CODE "init(x)=3.1\r"\
      CODE "init(y)=4.1\r"\
      CODE "// try using -4.1\r\r"\

    "Range[x]\r"\
      CODE "x = for 1 to 10 by 0.01\r"\
      CODE "y = range(1/((x-3)*(x-6)),-5,5)\r"\
      CODE "// alternative\r"\
      CODE "// y = 1/((x-3)*(x-6))"};

int16_t CurPage;
#define lenPrevPages 10
int16_t prevPages[lenPrevPages] = {0,0,0,0,0,0,0,0,0,0};
int16_t VScrollH;

#define AddCharHlp(c) { if ((link < 0) && (Cursory >= 0)) DrawChar(c,curHelpFont,curCol); }
#define AddStringHlp(s) { char *p = s; while (*p != 0) { AddCharHlp(*(p)); p++; } }

int16_t ShowHelpPage(int16_t page, int16_t link, int16_t VOffset)
{
  char *curHelpFont;
  uint16_t curCol;
  int16_t result;
  int8_t lnk;
  char *p;

  if (page < 0)
    return 0;

  VScrollH = imin(VOffset,(int16_t)0);

  if (prevPages[0] != page)
  {
    for (int8_t i = lenPrevPages-1; i >= 1; i--)
      prevPages[i] = prevPages[i-1];
    prevPages[0] = page;
  }

  CurPage = page;
  result = 255;
  p = pg[page];

  if (link < 0)
    ClearDisplay(TFT_BLACK);

  curHelpFont = (char*)CompactFont;
  curCol = TFT_WHITE;
  Cursorx = 0;
  Cursory = TextHeight(LargeFont)+1+VScrollH;

  lnk = 0;
  while ((*p != 0) && ((link >= 0) || (Cursory < tft_height+TextHeight(CompactFont)+1)))
  {
    if ((*p == WRAP[0]) || (*p == '\r'))
    {
      AddCharHlp('\r');
      curHelpFont = (char*)CompactFont;
      curCol = TFT_WHITE;
      Cursory += TextHeight(CompactFont)+1;
      Cursorx = 0;
    } else
    if (*p == COLCYAN[0]) curCol = TFT_CYAN; else
    if (*p == COLWHITE[0]) curCol = TFT_WHITE; else
    if (*p == TITLE[0]) curHelpFont = (char*)LargeFont; else
    if (*p == TAB[0]) { p++; Cursorx = imax(Cursorx,(*p-'a')*15); } else
    if (*p == BRA[0])  AddCharHlp('[') else
    if (*p == KET[0])  AddCharHlp(']') else
    if (*p == CODE[0]) { AddStringHlp(INDENT); curCol = TFT_CYAN; } else
    switch (*p) {
      case '[':
        {
          lnk++;
          int8_t k = 0;
          p++;
          if (*p == 'x')
          {
            curCol = TFT_CYAN;
            p++;
            if (lnk == link)
              result = pg[page]-p;
          } else
          {
            curCol = TFT_YELLOW;
            while (*p != ']')
            {
              k = k*10+*p-'0';
              p++;
            }
            if (lnk == link)
              result = k;
          }

          AddCharHlp('[');
          AddStringHlp(real_str(lnk % 10));
          AddCharHlp(']');
          curCol = TFT_WHITE;
        } break;

      case ' ': AddCharHlp(*p); break;
      
      default:
        AddCharHlp(*p);
    }
    if (*p != 0)
      p++;
  }
  return result;
}

void LoadCode(int16_t page,int16_t offset)
{
  int16_t i;
  char *p;
 
  LinesClear(false);
  i = 0;

  p = (char*)(&pg[page][offset]);
  while (*p != CODE[0])
    p++;

  do {
    p++;
    do {
      InsertChar(lines[i],*p,1000);
      p++;
    } while (!((*p == '\r') || (*p == 0)));
    while (*p == '\r')
    {
      i++;
      p++;
    }
  } while (*p == CODE[0]);

  SetImageMode(imEdit);
}

void HelpKeyPress(char Key)
{
  int16_t i;
  static int16_t k = 0;

  if ((Key >= '0') && (Key <= '9'))
  {
    i = ShowHelpPage(CurPage,Key-'0',0);
    if (i < 255)
      if (i >= 0)
        ShowHelpPage(i,-1,0); else
        LoadCode(CurPage,-i);
  } else
  switch (Key) {
    case Key_LEFT:
    case Key_BACK:
        for (i = 1; i <= lenPrevPages-1; i++)
          prevPages[i-1] = prevPages[i];
        prevPages[lenPrevPages-1] = 0;
        ShowHelpPage(prevPages[0],-1,0);
        break;

    case Key_UP: ShowHelpPage(CurPage,-1,VScrollH+TextHeight(CompactFont)+1); break;

    case Key_DOWN: ShowHelpPage(CurPage,-1,VScrollH-(TextHeight(CompactFont)+1)); break;

    case Key_RIGHT: ShowHelpPage(k,-1,0); k = (k+1) % (sizeof(pg)/sizeof(pg[0])); break;

    case '?':
    case Key_EXECUTE:  SetImageMode(imEdit); break;
  }
}
