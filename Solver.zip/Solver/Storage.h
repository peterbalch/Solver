//==============
// Storage.h
//==============

#ifndef Storage_h
#define Storage_h

void InitEEPROM();
void SaveFile();
void LoadLastFile();
void LoadPrevFile();
void LoadNextFile();
void ClearEEPROM();
void SaveAccIter(bool commit);

#define EEPROMsize  4096

//void add1Click(); // not in calculator
//void initWithSamples(); // not in calculator
//void listClick(); // not in calculator

#endif
