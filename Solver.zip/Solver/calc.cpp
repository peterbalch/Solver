//==============
// calc.cpp
//==============

#include "calc.h"
#include <stdint.h>
#include "calcdecl.h"
#include "math.h"
#include <limits.h>

bool calculate_value_known; // returned by calculate

int8_t error;

double execCalc(Pnode p); // forward

int16_t execExponent(double a)
{
  short *w;
  w = (short*)&a;

  if (a == 0)
    return 0; else
    return ((w[3] >> 4) & 0x7FF)-0x3FF;
}

double execAdd(double a, double b)
{
  double r;
  r = a+b;
  if (r >  MaxRealDbl)
    { error = 5; return MaxRealDbl; } else
  if (r < -MaxRealDbl)
    { error = 5; return -MaxRealDbl; } else
    return r;
}

double execSub(double a, double b)
{
  double r;
  r = a-b;
  if (r >  MaxRealDbl)
    { error = 6; return MaxRealDbl; } else
  if (r < -MaxRealDbl)
    { error = 6; return -MaxRealDbl; } else
    return r;
}

double execMult(double a, double b)
{
  int16_t e,MaxExponent;
  MaxExponent = 0x3FF;
  e = execExponent(a)+execExponent(b);
  if (e >= MaxExponent)
    { error = 1; return MaxRealDbl; } else
  if (e < -MaxExponent)
    { /* error = 2; */ return 0.0;     } else
    return a*b;
}

double execDivd(double a, double b)
{
  int16_t e;
  int16_t MaxExponent = 0x3FF;

  e = execExponent(a)-execExponent(b);
  if ((b==0.0) || (e >= MaxExponent))
    { error = 3; return MaxRealDbl; } else
  if (e < -MaxExponent             )
    { /* error = 4; */ return 0.0;     } else
    return a/b;
}

double execExp(double a)
{
  const double MaxExp = 708;
  if (a >  MaxExp)
    { error = 7; MaxRealDbl; } else
  if (a < -MaxExp)
    { /* error = 8; */ return 0.0;     } else
    return exp(a);
}

double execDeg(double a)
{
  return execDivd(execMult(a,180.0),M_PI);
}

double execRad(double a)
{
  return execDivd(execMult(a,M_PI),180.0);
}

double execSqrt(double a)
{
  if (a >= 0.0)
    return sqrt(a);
  error = 11;
  return 0.0;
}

double execSqr(double a)
{
  return execMult(a,a);
}

double execRange(double a,double min,double max)
{
  if (fabs(a) > max)
    error = 11; else
  if (fabs(a) < min)
    error = 11; else
    return a;
  return 0.0;
}

double execSin(double a)
{
  return sin(a);
}

double execCos(double a)
{
  return cos(a);
}

double execTan(double a)
{
  double b;
  b = execCos(a);
  if (b == 0.0)
    { error = 9; return MaxRealDbl; } else
    return execDivd(execSin(a),b);
}

double execArctan(double a)
{
  return atan(a);
}

double execArcsin(double a)
{
  if (fabs(a) < 1.0)
    return execArctan(execDivd(a,sqrt(1.0-a*a)));
  return M_PI/2;
}

double execArccos(double a)
{
  if (fabs(a) > 1.0)
    error = 9; else
  if (fabs(a) < 1.0)
    return execArctan(execDivd(execSqrt(1.0-a*a),a));
  return 0.0;
}

double execLn(double a)
{
  if (a <= 0.0)
    error = 10; else
    return log(a);
  return 0.0;
}

double execLog(double a)
{
  return execLn(a)/log(10.0);
}

double execPwr(double a, double b)
{
  if (b == 0)
    return 1; else
  if ((a == 0) && (b > 0))
    return 0; else
  if ((b < LONG_MAX) && (frac(b) == 0) && (a < 0))
  {
    if (odd(safeTrunc(b)))
      return -execExp(execLn(-a)*b); else
      return execExp(execLn(-a)*b);
  } else
    return execExp(execLn(a)*b);
}

double execMax(double a, double b)
{
  if (a > b) return a; else return b;
}

double execMin(double a, double b)
{
  if (a < b) return a; else return b;
}

double execIf(double a,double b,double c)
{
  if (a < 0)
    return b; else
    return c;
}

double execFor(Pnode i,Pnode from_,Pnode to_,Pnode by_)
{
  if (! i->V.initialised)
  {
    i->V.value = execCalc(from_);
//    execCalc(to_);
//    execCalc(by_);
    i->V.init_value = i->V.value;
    i->V.initialised = true;
  }

  return i->V.value;
}

double execCalc(Pnode p)
{
  double r;

  if (p == nullptr)
    return 0; else
  switch (p->B.op) {
    case opPlus:      return execAdd(execCalc(p->B.Left),execCalc(p->B.Right));
    case opMinus:     return execSub(execCalc(p->B.Left),execCalc(p->B.Right));
    case opNeg:       return -execCalc(p->B.Left);
    case opMlt:       return execMult(execCalc(p->B.Left),execCalc(p->B.Right));
    case opDivide:    return execDivd(execCalc(p->B.Left),execCalc(p->B.Right));
    case opRem:       r = execCalc(p->B.Right);
                      return execMult(frac(execDivd(execCalc(p->B.Left),r)),r);
    case opPwr_Fn:    return execPwr(execCalc(p->B.Left),execCalc(p->B.Right));
    case opCnst:      return p->V.value; 
    case opSin_Fn:    return execSin(execCalc(p->B.Left)); 
    case opCos_Fn:    return execCos(execCalc(p->B.Left)); 
    case opTan_Fn:    return execTan(execCalc(p->B.Left)); 
    case opArcsin_Fn: return execArcsin(execCalc(p->B.Left)); 
    case opArccos_Fn: return execArccos(execCalc(p->B.Left)); 
    case opArctan_Fn: return execArctan(execCalc(p->B.Left)); 
    case opDeg_Fn:    return execDeg(execCalc(p->B.Left)); 
    case opRad_Fn:    return execRad(execCalc(p->B.Left)); 
    case opLn_Fn:     return execLn(execCalc(p->B.Left)); 
    case opExp_Fn:    return execExp(execCalc(p->B.Left)); 
    case opLog_Fn:    return execLog(execCalc(p->B.Left));
    case opSqrt_Fn:   return execSqrt(execCalc(p->B.Left));
    case opSqr_Fn:    return execSqr(execCalc(p->B.Left));
    case opMax_Fn:    return execMax(execCalc(p->B.Left),execCalc(p->B.Right));
    case opMin_Fn:    return execMin(execCalc(p->B.Left),execCalc(p->B.Right));
    case opIf_Fn:     return execIf(execCalc(p->B.Left),execCalc(p->B.Right->B.Left),execCalc(p->B.Right->B.Right));
    case opFor_Fn:    return execFor(p->B.Left->B.Left,p->B.Left->B.Right,p->B.Right->B.Left,p->B.Right->B.Right);

    case opSet_Fn:    return execCalc(p->B.Left->B.Left);

    case opVar:       if (p->V.status != known)
                        calculate_value_known = false;
                      return p->V.value;

    case opAsgn: if (p->B.Left->B.op == opVar)
                 {
                   r = execCalc(p->B.Right);
                   p->B.Left->V.value = r;
                   return r;
                 } else
                   ;//RunError(0,"","Internal case error: Assignment error");
                   return 0;

    case opRange_Fn: return execRange(execCalc(p->B.Left),execCalc(p->B.Right->B.Left),execCalc(p->B.Right->B.Right));
    default: return 0; //RunError(0,"","Internal error: calc");
  }
}

double calculate(Pnode tree, int8_t *err)
{
  double result;
  error = 0;
  calculate_value_known = true;
  result = execCalc(tree);
  *err = error;
  return result;
}

double execMultiply(double a, double b, int8_t *err)
{
  double result;
  error = 0;
  result = execMult(a,b);
  *err = error;
  return result;
}

double execDivide(double a, double b, int8_t *err)
{
  double result;
  error = 0;
  result = execDivd(a,b);
  *err = error;
  return result;
}

double execPower(double a, double b, int8_t *err)
{
  double result;
  error = 0;
  result = execPwr(a,b);
  *err = error;
  return result;
}

double execNat_log(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execLn(a);
  *err = error;
  return result;
}

double execExponential(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execExp(a);
  *err = error;
  return result;
}

double execArcsine(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execArcsin(a);
  *err = error;
  return result;
}

double execArccosine(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execArccos(a);
  *err = error;
  return result;
}

double execArctangent(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execArctan(a);
  *err = error;
  return result;
}

double execSine(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execSin(a);
  *err = error;
  return result;
}

double execCosine(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execCos(a);
  *err = error;
  return result;
}

double execTangent(double a, int8_t *err)
{
  double result;
  error = 0;
  result = execTan(a);
  *err = error;
  return result;
}
