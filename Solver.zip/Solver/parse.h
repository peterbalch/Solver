//==============
// parse.h
//==============

#ifndef parse_h
#define parse_h

#include <stdint.h>

bool equation(char *s, int8_t *c, int8_t l, bool *init);

#endif
