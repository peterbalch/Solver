//==============
// Table.cpp
//==============

#include "Table.h"
#include "calcdecl.h"
#include "SimpleILI9341.h"
#include <stdint.h>
#include "VDU.h"

int16_t TableColWidth;
int16_t HScrollT;
int16_t VScrollT;
#define lenAnswerTable 1000
double AnswerTable[lenAnswerTable];
int16_t AnswerTableI;

void DrawHeader(Pnode p, int16_t *x, int16_t *y)
{
  char *q1,*q2;
  int16_t n;

  if (p == nullptr)
    return;

  DrawHeader(p->V.nextV,x,y);

  if ((p->V.name[0] == '?') && (p->V.name[1] == 'S'))
  {
    n = equations[p->V.name[2]-'a'+1].ScreenLine-1;
    q1 = lines[n];
    q2 = q1;
    while ((*q1 != 0) && (*q1 != '?'))
      q1++;
    while ((*q2 != 0) && (*q2 != '='))
      q2++;
    if (q2 < q1)
    { //xxx==?  q1==4 q2==3
      *q2 = 0;
      DrawStringAt(*x,*y,lines[n],(char*)CurFont, TFT_WHITE);
      *q2 = '=';
    } else
    { //?==xxx  q1==0 q2==2
      q2++;
      while (*q2 == ' ')
        q2++;
      DrawStringAt(*x,*y,q2,(char*)CurFont, TFT_WHITE);
    }
    *x = *x+TableColWidth;
  }
}

void DrawImageTable()
{
  int16_t x,y;
  int16_t i;

  ClearDisplay(TFT_BLACK);

  y = (1-VScrollT)*(TXTH) -3;
  x = 1-HScrollT*TableColWidth / 3;
  DrawHeader(global_name_list,&x,&y);
  y = y+TXTH;
  x = 1-HScrollT*TableColWidth / 3;

  for (i = 0; i<=AnswerTableI-1; i++)
  {
    if (AnswerTable[i] == -MaxRealDbl)
    {
      y = y+TXTH;
      x = 1-HScrollT*TableColWidth / 3;
    } else
    if ((y >= 0) && (y < tft_height+TXTH))
    {
      if (AnswerTable[i] == MaxRealDbl)
      {
        DrawStringAt(x,y,"     ?",(char*)CurFont, TFT_WHITE);
        x = 1+x+TableColWidth;
      } else
      {
        DrawStringAt(x,y,real_str(AnswerTable[i]),(char*)CurFont, TFT_WHITE);
        x = x+TableColWidth;
      }
    }
  }
}

void TableFormKeyPress(char Key)
{
  switch (Key) {
    case Key_LEFT:
        if (HScrollT > 0)
          HScrollT--;
        DrawImageTable();
        break;

    case Key_UP:
        if (VScrollT > 0)
        {
          VScrollT--;
          DrawImageTable();
        }
        break;

    case Key_DOWN:
        VScrollT++;
        DrawImageTable();
        break;

    case Key_RIGHT:
        HScrollT++;
        DrawImageTable();
        break;

    case Key_EXECUTE: SolveBtnClicked(); break;
  }
}

void ResetTable()
{
  TableColWidth = TextWidth("0",CurFont) * ((NumLength+5) / 3)*3;
  HScrollT = 0;
  VScrollT = 0;
  AnswerTableI = 0;
}

void AddNumToAnswerTable(double value)
{
  if (AnswerTableI < lenAnswerTable-1)
  {
    AnswerTable[AnswerTableI] = value;
    AnswerTableI++;
  }
}

void AddQuToAnswerTable()
{
  AddNumToAnswerTable(MaxRealDbl);
}

void AddLineToAnswerTable()
{
  AddNumToAnswerTable(-MaxRealDbl);
}
