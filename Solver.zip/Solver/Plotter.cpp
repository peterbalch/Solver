//==============
// Plotter.cpp
//==============

#include "Plotter.h"

#include "calcdecl.h"
#include "SimpleILI9341.h"
#include <stdint.h>
#include "VDU.h"

#define min2DProj  (1.0/6)
#define max2DProj  (5.0/6)
#define YawMax  32
#define PitchMax  32
#define MaxPlotLines  1000

struct TAxisRec {
      double value,prev_value,min,max;
      bool has_value,prev_has_value;
    };
struct T3DPoint {float x,y,z;};

TAxisRec axes[3];
int8_t yaw,pitch;
double sinYaw,cosYaw,sinPitch,cosPitch,xOfs,yOfs,scale;
T3DPoint PlotLines[MaxPlotLines];
int16_t numPlotLines;

void proj(double x,double y,double z, double *u, double *v)
{
  double x1,y1;

  if (is3Dplot)
  {
    x1 = x*cosYaw-y*sinYaw;
    y1 = x*sinYaw+y*cosYaw;

    *u = y1;
    *v = -x1*sinPitch+z*cosPitch;
    *u = xOfs+scale**u;
    *v = yOfs-scale**v;
  } else
  {
    *u = x*(max2DProj-min2DProj)+min2DProj;
    *v = max2DProj-y*(max2DProj-min2DProj);
  }
}

void PlotDrawLine(double x1,double y1,double z1,double x2,double y2,double z2, uint16_t Col)
{
  double u1,v1,u2,v2;
  int16_t ix1,iy1,ix2,iy2;

  proj(x1,y1,z1,&u1,&v1);
  proj(x2,y2,z2,&u2,&v2);

  ix1 = safeTrunc(u1*tft_width);
  iy1 = safeTrunc(v1*tft_height);
  ix2 = safeTrunc(u2*tft_width);
  iy2 = safeTrunc(v2*tft_height);

  DrawLine(ix1,iy1,ix2,iy2,Col);
}

double PlotTextwidth(char *s)
{
  double x = TextWidth(s,(char*)CurFont);
  return (float)x / tft_width;
}

double PlotTextHeight()
{
  double y = TXTH;
  return (float)y / tft_height;
}

void PlotDrawText(char *s, double x1,double y1,double z1, Tlayout xLayout,Tlayout yLayout)
{
  double u1,v1,w,h;
  
  proj(x1,y1,z1,&u1,&v1);

  h = PlotTextHeight();
  w = PlotTextwidth(s);

  switch (yLayout) {
    case lyUp:     v1 = v1-h; break;
    case lyCentre: v1 = v1-h/2; break;
  }

  switch (xLayout) {
    case lyLeft:   u1 = u1-w; break;
    case lyCentre: u1 = u1-w/2; break;
  }
  if (u1+w > 1) u1 = 1-w;
  if (u1   < 0) u1 = 0;

  DrawStringAt(safeTrunc(u1*tft_width),safeTrunc(v1*tft_height)+TXTH,s,(char*)CurFont, TFT_WHITE);
}

void PlotDrawNum(double a, double x1,double y1,double z1, Tlayout xLayout,Tlayout yLayout)
{
  PlotDrawText(real_str(a),x1,y1,z1,xLayout,yLayout);
}

double scale0to1(double v, Taxis_type ax )
{
  double x;
  if (axes[ax].max-axes[ax].min == 0)
    x = 0; else
    x = safeDiv(v-axes[ax].min,axes[ax].max-axes[ax].min);
  if (x < -1000 ) x = -1000; else if (x > 2000) x = 2000;
  return x;
}

void SetYawPitch(int8_t aYaw,int8_t aPitch)
{
  double u,v;

  yaw = aYaw;
  pitch = aPitch;
  sinYaw = sin(yaw*2*PI/YawMax);   cosYaw = cos(yaw*2*PI/YawMax);
  sinPitch = sin(pitch*PI/2/PitchMax); cosPitch = cos(pitch*PI/2/PitchMax);
  xOfs = 0;
  yOfs = 0;
  scale = 0.5;
  proj(0.5,0.5,0.5,&u,&v);
  xOfs = 0.5-u;
  yOfs = 0.5-v;
  proj(0.5,0.5,0.5,&u,&v);
}

#define Tick3D 0.05

void Draw3DXaxis(double z0)
{
  Tlayout l;
  double t1,t2;

  if (is3Dplot)
  {
    switch (yaw*8 / YawMax) {
      case 0:
      case 1:   { l = lyLeft;  t2 = -Tick3D;  t1 = 1; } break;
      case 2:
      case 3:   { l = lyRight; t2 = -Tick3D;  t1 = 1; } break;
      case 4:
      case 5:   { l = lyLeft;  t2 = 1+Tick3D; t1 = 0; } break;
      case 6:
      case 7:
      case 8: { l = lyRight; t2 = 1+Tick3D; t1 = 0; } break;
    }

    PlotDrawText(real_str(axes[x_axis].min), 0,  t2,z0, l,lyDown);
    PlotDrawText(real_str(axes[x_axis].max), 1,  t2,z0, l,lyDown);
    PlotDrawText("x",                              0.5,t2,z0, l,lyDown);
    PlotDrawLine(0,t2,z0, 0,t1,z0, TFT_WHITE);
    PlotDrawLine(1,t2,z0, 1,t1,z0, TFT_WHITE);
  }
}

void Draw3DYaxis(double z0)
{
  Tlayout l;
  double t1,t2;

  if (is3Dplot)
  {
    switch (yaw*8 / YawMax) {
      case 0:
      case 1:   { l = lyRight; t1 = 1+Tick3D; t2 = 0; } break;
      case 2:
      case 3:   { l = lyLeft;  t1 = -Tick3D;  t2 = 1; } break;
      case 4:
      case 5:   { l = lyRight; t1 = -Tick3D;  t2 = 1; } break;
      case 6:
      case 7:
      case 8: { l = lyLeft;  t1 = 1+Tick3D; t2 = 0; } break;
    }
    PlotDrawText(real_str(axes[y_axis].min), t1,0,  z0, l,lyDown);
    PlotDrawText(real_str(axes[y_axis].max), t1,1,  z0, l,lyDown);
    PlotDrawText("y",                              t1,0.5,z0, l,lyDown);
    PlotDrawLine(t1,1,z0, t2,1,z0, TFT_WHITE);
    PlotDrawLine(t1,0,z0, t2,0,z0, TFT_WHITE);
  }
}

void Draw3DZaxis(double z0)
{
  Tlayout l;
  double t1,t2;

  if (is3Dplot)
  {
    switch (yaw*8 / YawMax) {
      case 0:
      case 7:
      case 8: { t1 = 0;       t2 = -Tick3D; l = lyLeft;  } break;
      case 1:
      case 2:   { t1 = -Tick3D; t2 = 0;       l = lyLeft;  } break;
      case 3:
      case 4:   { t1 = 0;       t2 = -Tick3D; l = lyRight; } break;
      case 5:
      case 6:   { t1 = -Tick3D; t2 = 0;       l = lyRight; } break;
    }
    PlotDrawText(real_str(axes[z_axis].min), t1,t2,0,  l,lyUp);
    PlotDrawText(real_str(axes[z_axis].max), t1,t2,1,  l,lyDown);
    PlotDrawText("z",                         t1,t2,0.5+Tick3D,l,lyCentre);
    PlotDrawLine(t1,t2,1, 0,0,1, TFT_WHITE);
    PlotDrawLine(t1,t2,0, 0,0,0, TFT_WHITE);
    PlotDrawLine(0, 0, 0, 0,0,1, TFT_WHITE);
  }
}

void Draw3DAxes()
{
  double z0;
  z0 = safeDiv(axes[z_axis].min,axes[z_axis].min-axes[z_axis].max);
  if (z0 < 0 ) z0 = 0; else if (z0 > 1) z0 = 1;

  Draw3DXaxis(z0);
  Draw3DYaxis(z0);
  Draw3DZaxis(z0);
}

double posn(Taxis_type ax)
{
  double x;
  x = scale0to1(0,ax);
  if (x < 0) x = 0;
  if (x > 1) x = 1;
  return x;
}

#define Tick2D 0.025

void Draw2DXaxis()
{
  double y0;

  y0 = posn(y_axis);

  PlotDrawText(real_str(axes[x_axis].min), 0,y0-Tick2D,0,  lyCentre, lyDown);
  PlotDrawText(real_str(axes[x_axis].max), 1,y0-Tick2D,0,  lyCentre, lyDown);
  PlotDrawText("x",                      0.5,y0,       0,  lyCentre, lyDown);

  PlotDrawLine(0, y0-Tick2D,0,    0, y0       ,0,  TFT_WHITE);
  PlotDrawLine(0, y0       ,0,    1, y0       ,0,  TFT_WHITE);
  PlotDrawLine(1, y0       ,0,    1, y0-Tick2D,0,  TFT_WHITE);
}

void Draw2DYaxis()
{
  double x0;
  x0 = posn(x_axis);

  PlotDrawText(real_str(axes[y_axis].min), x0-Tick2D, 0,  0,  lyLeft,  lyCentre);
  PlotDrawText(real_str(axes[y_axis].max), x0-Tick2D, 1,  0,  lyLeft,  lyCentre);
  PlotDrawText("y",                        x0-Tick2D, 0.5,0,  lyLeft,  lyUp);

  PlotDrawLine(x0-Tick2D, 0,0,    x0,        0,0,  TFT_WHITE);
  PlotDrawLine(x0,        0,0,    x0,        1,0,  TFT_WHITE);
  PlotDrawLine(x0,        1,0,    x0-Tick2D, 1,0,  TFT_WHITE);
}

void Draw2DAxes()
{
  Draw2DXaxis();
  Draw2DYaxis();
}

void DrawImagePlot()
{
  int16_t i;
  bool PenDown;
  double u1,v1;
  double prevu1,prevv1;

  ClearDisplay( TFT_BLACK);
  SetYawPitch(yaw,pitch);

  if (is3Dplot)
    Draw3DAxes(); else
    Draw2DAxes();

  PenDown = false;
  for (i = 0; i < numPlotLines; i++) 
  {
    if ((PlotLines[i].x == MaxRealSgl) ||
       (PlotLines[i].y == MaxRealSgl) ||
       (is3Dplot && (PlotLines[i].z == MaxRealSgl)) )
      PenDown = false; else
    {
      proj(
        scale0to1(PlotLines[i].x,x_axis),
        scale0to1(PlotLines[i].y,y_axis),
        scale0to1(PlotLines[i].z,z_axis),
        &u1,&v1);

      u1 = safeTrunc(u1*tft_width);
      v1 = safeTrunc(v1*tft_height);
      if (PenDown)
        DrawLine((int16_t)prevu1,(int16_t)prevv1,(int16_t)u1,(int16_t)v1,TFT_CYAN);
      prevu1 = u1;
      prevv1 = v1;
      PenDown = true;
    }
  }
}

void reset_axis(Taxis_type ax)
  /* called when a plot(...) is parsed */
{
    axes[ax].value = 0;
    axes[ax].prev_value = 0;
    axes[ax].min = 1;
    axes[ax].max = 0;
    axes[ax].has_value = false;
    axes[ax].prev_has_value = false;
}

void ResetPlot()
{
  reset_axis(x_axis);
  reset_axis(y_axis);
  reset_axis(z_axis);
  SetYawPitch(4,4);
  numPlotLines = 0;
}

void coord(Taxis_type ax, double v, Pnode varb)
  /* called when one coordinate value has been found */
{
    axes[ax].value = v;
    axes[ax].has_value = true;
    if (axes[ax].min > axes[ax].max)
    {
      axes[ax].min = v;
      axes[ax].max = v;
    }
    if (v < axes[ax].min)
      axes[ax].min = v;
    if (v > axes[ax].max)
      axes[ax].max = v;
}

void NewPlotLine()
  /* called after a for loop has finished - starts a new line */
{
  Taxis_type ax;

  for (ax = x_axis; ax<=z_axis; ax=(Taxis_type)(ax+1))
  {
    axes[ax].prev_has_value = false;
    axes[ax].has_value = false;
  }

  if (numPlotLines < MaxPlotLines-1)
  {
    PlotLines[numPlotLines].x = MaxRealSgl;
    PlotLines[numPlotLines].y = MaxRealSgl;
    PlotLines[numPlotLines].z = MaxRealSgl;
    numPlotLines++;
  }
}

void CoordsFound()
  /* called after equs has been solved once but before calls to coord */
{
  Taxis_type ax;
  for (ax = x_axis; ax<=z_axis; ax=(Taxis_type)(ax+1))
  {
    axes[ax].prev_value = axes[ax].value;
    axes[ax].prev_has_value = axes[ax].has_value;
    axes[ax].has_value = false;
  }
}

void AllCoordsFound()
  /* called when all coords have been found */
{
  if (numPlotLines < MaxPlotLines-1)
  {
    if (axes[x_axis].has_value)
      PlotLines[numPlotLines].x = axes[x_axis].value; else
      PlotLines[numPlotLines].x = MaxRealSgl;
    if (axes[y_axis].has_value)
      PlotLines[numPlotLines].y = axes[y_axis].value; else
      PlotLines[numPlotLines].y = MaxRealSgl;
    if (axes[z_axis].has_value)
      PlotLines[numPlotLines].z = axes[z_axis].value; else
      PlotLines[numPlotLines].z = MaxRealSgl;
    numPlotLines++;
  }
}

void PlotterFormKeyPress(char Key)
{
  switch (Key) {
    case Key_LEFT:    { SetYawPitch((yaw-1+YawMax) % YawMax,pitch); DrawImagePlot(); } break;
    case Key_UP:      { if (pitch > -32 ) SetYawPitch(yaw,pitch-1); DrawImagePlot(); } break;
    case Key_DOWN:    { if (pitch <  32 ) SetYawPitch(yaw,pitch+1); DrawImagePlot(); } break;
    case Key_RIGHT:   { SetYawPitch((yaw+1+YawMax) % YawMax,pitch); DrawImagePlot(); } break;
    case Key_EXECUTE: SolveBtnClicked();
  }
}
