//==============
// solver.cpp
//==============

#include "solver.h"
#include <stdint.h>
#include "math.h"
#include "calc.h"
#include "gauss.h"
#include "plotter.h"
#include "table.h"
#include "VDU.h"
#include "string.h"
#include "storage.h"
#include "parse.h"
#include <limits.h>
#include "memory.h"

double found_neg,found_negf,found_pos,found_posf;
int16_t nTry;
int16_t NumEqus;
int16_t minLine,maxLine;

//bool solve_strings() {return false;}

void found(double r,double f)
{
  if ((f <= 0) && ((found_negf > 0) || (found_negf < f)))
    { found_neg = r; found_negf = f; }
  if ((f >= 0) && ((found_posf < 0) || (found_posf > f)))
    { found_pos = r; found_posf = f; }
}

double new_num(bool *first)
{
  static int16_t i = 1;
  static double r = 1;
  int8_t error;

  if (*first)
    { i = 1; r = 1; }

    switch (i % 4) {
    case 0:
         r = execDivide(2,r,&error);
           if (error != 0)
             r = 1;
            break;
    case 2:   r = 1/r;  break;
    default: r = -r;
  }
  i++;
  *first = false;
  return r;
}

double **pneg;

void find(TequRec *equ, double *neg, double *pos, bool *first)
{
  int8_t error;
  double fx;
  if (found_negf <= 0) *neg = found_neg; else
  {
    *neg = new_num(first);
    equ->depend->V.value = *neg;
    fx = calculate(equ->tree,&error);
    if (error == 0) found(equ->depend->V.value,fx);
    *neg = found_neg;
  }

  if (found_posf >= 0) *pos = found_pos; else
  {
    *pos = new_num(first);
    equ->depend->V.value = *pos;
    fx = calculate(equ->tree,&error);
    if (error == 0) found(equ->depend->V.value,fx);
    *pos = found_pos;
  }
}


void calc(Pnode p, double expr_value, int8_t *error)
{
  double r;
  
  if (p == nullptr)
    *error = 12; else
  {
    switch (p->B.op) {
      case opVar:      p->V.value = expr_value;  break;
      case opPlus:
               r = calculate(p->B.Left,error); if (*error != 0) return;
               if (calculate_value_known)
                 calc(p->B.Right,expr_value-r,error); else
               {
                 r = calculate(p->B.Right,error); if (*error != 0) return;
                 if (calculate_value_known)
                   calc(p->B.Left,expr_value-r,error); else
                   *error = 12;
               }
               break;
      case opMinus:
                r = calculate(p->B.Left,error); if (*error != 0) return;
                if (calculate_value_known)
                  calc(p->B.Right,r-expr_value,error); else
                {
                r = calculate(p->B.Right,error); if (*error != 0) return;
                  if (calculate_value_known)
                    calc(p->B.Left,expr_value+r,error); else
                    *error = 12;
                }
                break;
      case opMlt:
                r = calculate(p->B.Left,error); if (*error != 0) return;
                if (calculate_value_known)
                {
                  expr_value = execDivide(expr_value,r,error); if (*error != 0) return;
                  calc(p->B.Right,expr_value,error);
                } else
                {
                  r = calculate(p->B.Right,error); if (*error != 0) return;
                  if (calculate_value_known)
                  {
                    expr_value = execDivide(expr_value,r,error); if (*error != 0) return;
                    calc(p->B.Left,expr_value,error);
                  } else
                    *error = 12;
                }
                break;
      case opDivide:
                r = calculate(p->B.Left,error); if (*error != 0) return;
                if (calculate_value_known)
                {
                  expr_value = execDivide(r,expr_value,error); if (*error != 0) return;
                  calc(p->B.Right,expr_value,error);
                } else
                {
                  r = calculate(p->B.Right,error); if (*error != 0) return;
                  if (calculate_value_known)
                  {
                    expr_value = execMultiply(expr_value,r,error); if (*error != 0) return;
                    calc(p->B.Left,expr_value,error);
                  } else
                    *error = 12;
                }
                break;
      case opRem:
                r = calculate(p->B.Left,error); if (*error != 0) return;
                if ((calculate_value_known) &&
                    (r > execMultiply(2,expr_value,error)))
                  calc(p->B.Right,r-expr_value,error); else
                {
                  r = calculate(p->B.Right,error); if (*error != 0) return;
                  if ((calculate_value_known) &&
                     (r > expr_value))
                    calc(p->B.Left,expr_value,error); else
                    *error = 12;
                }
                break;
      case opPwr_Fn:
                r = calculate(p->B.Left,error); if (*error != 0) return;
                if (calculate_value_known)
                {
                  expr_value = execNat_log(expr_value,error); if (*error != 0) return;
                  r = execNat_log(r,error); if (*error != 0) return;
                  expr_value = execDivide(expr_value,r,error); if (*error != 0) return;
                  calc(p->B.Right,expr_value,error);
                } else
                {
                  r = calculate(p->B.Right,error); if (*error != 0) return;
                  if (calculate_value_known)
                  {
                    r = execDivide(1,r,error); if (*error != 0) return;
                    expr_value = execPower(expr_value,r,error); if (*error != 0) return;
                    calc(p->B.Left,expr_value,error);
                  } else
                    *error = 12;
                }
                break;
      case opNeg:       calc(p->B.Left,-expr_value,error); break;
      case opSin_Fn:
                  expr_value = execArcsine(expr_value,error); if (*error != 0) return;
                  calc(p->B.Left,expr_value,error);
                  break;
      case opCos_Fn:
                   expr_value = execArccosine(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opTan_Fn:
                   expr_value = execArctangent(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opArcsin_Fn:
                   expr_value = execSine(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opArccos_Fn:
                   expr_value = execCosine(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opArctan_Fn:
                   expr_value = execTangent(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opDeg_Fn:
                   expr_value = execMultiply(expr_value,M_PI,error); if (*error != 0) return;
                   expr_value = execDivide(expr_value,180,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opRad_Fn:
                   expr_value = execMultiply(expr_value,180,error); if (*error != 0) return;
                   expr_value = execDivide(expr_value,M_PI,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opLn_Fn:
                   expr_value = execExponential(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opExp_Fn:
                   expr_value = execNat_log(expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opLog_Fn:
                   expr_value = execPower(10,expr_value,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opSqrt_Fn:
                   expr_value = execPower(expr_value,2,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opSqr_Fn:
                   expr_value = execPower(expr_value,0.5,error); if (*error != 0) return;
                   calc(p->B.Left,expr_value,error);
                  break;
      case opIf_Fn:
               r = calculate(p->B.Left,error); if (*error != 0) return;
               if (calculate_value_known)
               {
                 if (r < 0)
                   calc(p->B.Right->B.Left,expr_value,error); else
                   calc(p->B.Right->B.Right,expr_value,error);
               } else
                 *error = 12;
               break;
      case opMax_Fn:
                 r = calculate(p->B.Left,error); if (*error != 0) return;
                 if (calculate_value_known && (r < expr_value))
                   calc(p->B.Right,expr_value,error); else
                 {
                   r = calculate(p->B.Right,error); if (*error != 0) return;
                   if (calculate_value_known && (r < expr_value))
                     calc(p->B.Left,expr_value,error); else
                     *error = 12;
                 }
                 break;
      case opMin_Fn:
               r = calculate(p->B.Left,error); if (*error != 0) return;
               if (calculate_value_known && (r > expr_value))
                 calc(p->B.Right,expr_value,error); else
               {
                 r = calculate(p->B.Right,error); if (*error != 0) return;
                 if (calculate_value_known && (r > expr_value))
                   calc(p->B.Left,expr_value,error); else
                   *error = 12;
               }
               break;
     default:       *error = 12;
    }
  }
}

bool Direct(int8_t l)
{
  int8_t error;
  error = 0;
  calc(equations[l].tree,0,&error);

  return error == 0;
}

bool Secant(int8_t l)
{
  double test,testf,prev,prevf,next_test;
  int8_t error;
  Pnode unkv;
  bool first;

  first = true;
  unkv = equations[l].depend;
  test = unkv->V.init_value;

  prev = test-0.01;
  unkv->V.value = prev;
  prevf = calculate(equations[l].tree,&error);
  if (error != 0) found(prev,prevf);

  for (nTry = 1; nTry <= Iterations / 2; nTry++) 
  {
    unkv->V.value = test;
    testf = calculate(equations[l].tree,&error);
    if (error != 0) found(test,testf);
    if ((fabs(test-prev) < Accuracy) && (fabs(testf) < Accuracy))
      return true;
    if ((error != 0) || ((testf-prevf) == 0))
    {
  test = new_num(&first);
  prev = new_num(&first);
  unkv->V.value = prev;
  prevf = calculate(equations[l].tree,&error);
  if (error != 0) found(prev,prevf);
    } else
    {
      error = 0;
      next_test = execMultiply(test,prevf,&error);
      execMultiply(prev,testf,&error);
      if (error == 0)
        next_test = next_test - execMultiply(prev,testf,&error);
      if (error == 0)
        next_test = execDivide(next_test,prevf-testf,&error);
      if (error != 0)
      {
    test = new_num(&first);
    prev = new_num(&first);
    unkv->V.value = prev;
    prevf = calculate(equations[l].tree,&error);
    if (error != 0) found(prev,prevf);
      } else
      {
    prev = test;
    prevf = testf;
        test = next_test;
      }
  if (error != 0) found(prev,prevf);
    }
  }
  return false;
}

bool chop(int8_t l)
{
  double neg,pos,test,negf,posf,testf;
  int8_t error;
  Pnode unkv;
  bool first;

  first = true;
  unkv = equations[l].depend;
  find(&equations[l],&neg,&pos,&first);

  while (nTry < Iterations)
  {
    nTry++;
    unkv->V.value = neg;
    negf = calculate(equations[l].tree,&error);
    unkv->V.value = pos;
    if (error == 0)
      posf = calculate(equations[l].tree,&error);

    if ((error != 0) ||
       ((negf > 0) || (posf < 0) || (error != 0)) ||
       ((fabs(neg-pos) < Accuracy) && (fabs(negf+posf) > 1)) ||
       (posf-negf == 0))
    {
      found_negf = +1;
      found_posf = -1;
      find(&equations[l],&neg,&pos,&first);
    } else
    {
      if ((fabs(neg-pos) < Accuracy) && (fabs(negf) < Accuracy) &&
         (fabs(posf) < Accuracy))
          return true;
      if (odd(nTry) && (posf != negf))
      {
        test = execDivide(execMultiply(neg,posf,&error) -
          execMultiply(pos,negf,&error),posf-negf,&error);
      } else
        test = execDivide(pos+neg,2,&error);
      unkv->V.value = test; testf = calculate(equations[l].tree,&error);
      if (testf <= 0) neg = test;
      if (testf >= 0) pos = test;
    }
  }
  return false;
}

bool to_be_solved(int8_t l)
{
  PReferenceRec p;
  double test;
  int8_t error;

  if (equations[l].uselist == nullptr)
    return false;

  equations[l].depend = nullptr;

  p = equations[l].uselist;
  while (p != nullptr)
  {
    if (p->ref->V.status != known)
    {
      if (equations[l].depend != nullptr)
        return false;
      equations[l].depend = p->ref;
    }
    p = p->nextR;
  }
  if (equations[l].depend == nullptr)
  {
    test = calculate(equations[l].tree,&error);
    equations[l].equal = (fabs(test) < Accuracy) && (error == 0);
    calculate(equations[l].tree,&error);
    return false;
  }
  return true;
}

bool iterate(Pnode *v, bool *done, double delta, int8_t *lin)
{
  double x[equMax+1];
  int8_t i,j;
  int8_t error;

  *v = global_name_list;
  j = 0;
  while (*v != nullptr)
  {
    if ((*v)->V.status == unknown)
    {
      j = j+1;
      x[j] = (*v)->V.value;
      (*v)->V.value = (*v)->V.value+delta;
      for (i = 1; i<= matSize; i++)
      {
        setTestMatrix(i,j,calculate(equations[lin[i]].tree,&error));
        if (error != 0)
          return false;
      }
      (*v)->V.value = (*v)->V.value-delta;
    }
    *v = (*v)->V.nextV;
  }

  for (i = 1; i<= matSize; i++)
  {
    setTestMatrix(i,0,calculate(equations[lin[i]].tree,&error));
    if (error != 0)
      return false;
    for (j = 1; j <= matSize; j++)
    {
      setMatrix(i,j,execDivide(getTestMatrix(i,j)-getTestMatrix(i,0),delta,&error));
      if (error != 0)
        return false;
    }
  }
  for (i = 1; i<= matSize; i++)
  {
    setMatrix(i,0,getTestMatrix(i,0));
    for (j = 1; j <= matSize; j++)
    {
      setMatrix(i,0,getMatrix(i,0)-execMultiply(getMatrix(i,j),x[j],&error));
      if (error != 0)
        return false;
    }
  }
//double d[12];

  if (!gaussian_eliminate())
    return false;

  *done = true;
  i = 0;
  *v = global_name_list;
  while (*v != nullptr)
  {
    if ((*v)->V.status == unknown)
    {
      i = i+1;
      if (fabs((*v)->V.value-getMatrix(i,0)) >= Accuracy)
        *done = false;
      (*v)->V.value = getMatrix(i,0);
    }
    *v = (*v)->V.nextV;
  }

  for (i = 1; i<= matSize; i++)
  {
    if (fabs(calculate(equations[lin[i]].tree,&error)) >= Accuracy)
      *done = false;
    if (error != 0)
      return false;
  }

  return true;
}

bool Simult()
{
  int8_t error;
  Pnode v;
  bool done;
  double delta;
  int8_t lin[equMax+1];
  bool first;
  PReferenceRec p;
  int8_t i,j,l;

  first = true;
  v = global_name_list;
  while (v != nullptr)
  {
    if (v->V.status != known)
    {
      v->V.value = v->V.init_value;
      v->V.status = unknown;
    }
    v = v->V.nextV;
  }

  matSize = 0;
  for (l = minLine; l<=maxLine; l++)
  if (!to_be_solved(l) && (equations[l].depend != nullptr) && (equations[l].uselist != nullptr))
  {
    matSize++;
    lin[matSize] = l;
  }

  v = global_name_list;
  while (v != nullptr)
  {
    if (v->V.status == unknown)
    {
      j = 0;
      for (i = 1; i<= matSize; i++)
      {
        p = equations[lin[i]].uselist;
        while (p != nullptr)
        {
          if (p->ref == v)
            { j = j+1; l = i; }
          p = p->nextR;
        }
      }
      if (j == 1)
      {
        for (j = l+1; j<=matSize; j++) 
          lin[j-1] = lin[j];
        matSize = matSize-1;
        v->V.status = unwanted;
      }
    }
    v = v->V.nextV;
  }

  v = global_name_list;
  j = 0;
  while (v != nullptr)
  {
    if (v->V.status == unknown) j = j+1;
    v = v->V.nextV;
  }

  if (matSize != j)
    return false;

  if (! AllocateMatrix())
    return false;

  delta = 1;
  nTry = 1;
  do {
    if (! iterate(&v, &done, delta, lin))
    {
      v = global_name_list;
      while (v != nullptr)
      {
        if (v->V.status == unknown) v->V.value = new_num(&first);
        v = v->V.nextV;
      }
      done = false;
    }
    if (delta > Accuracy)
      delta = execDivide(delta,2,&error);
    nTry = nTry+1;
  } while (!( done || (nTry > Iterations)));

  v = global_name_list;
  while (v != nullptr)
  {
    switch (v->V.status) {
      case known:    v->V.status = known; break;
      case unknown:  if (done) v->V.status = known; else v->V.status = unknown; break;
      case unwanted: v->V.status = unknown; break;
    }
    v = v->V.nextV;
  }
  return done;
}

bool solve(int8_t l)
{
  found_negf = +1;
  found_posf = -1;

  if (Direct(l))
  {
    equations[l].depend->V.status = known;
    return true;
  }

  if (Secant(l))
  {
    equations[l].depend->V.status = known;
    return true;
  }

  if (chop(l))
  {
    equations[l].depend->V.status = known;
    return true;
  }
  return false;
}

bool write_knowns(Pnode p, bool table_columns)
{
  static bool written = false;
  bool result = true;

  if (p == global_name_list) written = false;

  if (p == nullptr)
    return result;

  if (! write_knowns(p->V.nextV,table_columns))
    result = false;

  if (p->V.status != known)
  {
    if ((p->V.name[0] == '?') && (p->V.name[1] == 'S'))
      if (table_columns)
        AddQuToAnswerTable();
    result = false;
  } else
  if ((p->V.name[0] == '?') && (p->V.name[1] == 'S'))
  {
    if (has_fors)
    {
      if (table_columns)
        if (equations[p->V.name[2]-'a'+1].equal)
          AddNumToAnswerTable(p->V.value); else
          AddQuToAnswerTable();
       written = true;
    } else
    {
      InsertAnswer(p->V.name[3]-'a'+1,
        equations[p->V.name[2]-'a'+1].ScreenLine,
        real_str(p->V.value));
    }
  } else
  if (has_plot && (strcmp(p->V.name,"X") == 0) && table_columns)
      coord(x_axis,p->V.value,p); else
  if (has_plot && (strcmp(p->V.name,"Y") == 0) && table_columns)
      coord(y_axis,p->V.value,p); else
  if (has_plot && (strcmp(p->V.name,"Z") == 0) && table_columns)
      coord(z_axis,p->V.value,p); else
  if (strcmp(p->V.name,"ACCURACY") == 0)
  {
    Accuracy = p->V.value;
    SaveAccIter(true);
  } else
  if ((strcmp(p->V.name,"ITERATIONS") == 0) && (p->V.value > 0) && (p->V.value < LONG_MAX))
  {
    Iterations = safeTrunc(p->V.value);
    SaveAccIter(true);
  }

  if (has_fors && table_columns && (p == global_name_list))
      AddLineToAnswerTable();
  return result;
}

bool check_equal()
{
  int8_t y;

  for (y = minLine; y<=maxLine; y++)
    if (! equations[y].equal)
    {
      RunError(y,-1);
      return false;
    }
  return true;
}

bool increment_generator(Pnode p)
{
  double a,r;
  int8_t error;

  if (p == nullptr)
    return false;

  switch (p->B.op) {
    case opPlus:
    case opMinus:
    case opMlt:
    case opDivide:
    case opRem:
    case opPwr_Fn:
    case opMin_Fn:
    case opMax_Fn:
    case opIf_Fn:
      return increment_generator(p->B.Right) || increment_generator(p->B.Left);

    case opNeg:
    case opSin_Fn:
    case opCos_Fn:
    case opTan_Fn:
    case opArcsin_Fn:
    case opArccos_Fn:
    case opArctan_Fn:
    case opRad_Fn:
    case opDeg_Fn:
    case opLn_Fn:
    case opExp_Fn:
    case opLog_Fn:
    case opSqrt_Fn:
    case opSqr_Fn:
    case opRange_Fn:
      return increment_generator(p->B.Left);

    case opAsgn:
      return increment_generator(p->B.Right);

    case opFor_Fn:
      {
        r = calculate(p->B.Right->B.Right,&error);
        if ((error != 0) || (r == 0.0))
          return false;
        p->B.Left->B.Left->V.value = p->B.Left->B.Left->V.value+r;
        if (fabs(p->B.Left->B.Left->V.value) < Accuracy)
          p->B.Left->B.Left->V.value = 0;

        a = p->B.Left->B.Left->V.value - calculate(p->B.Right->B.Left,&error);
        if ((a==0) || ((a>0) == (r<0)))
          return error == 0; else
        {
          p->B.Left->B.Left->V.value = p->B.Left->B.Left->V.init_value;
          NewPlotLine();
          AddLineToAnswerTable();
        }
      } break;

    case opSet_Fn:
      {
        p->B.Left = p->B.Left->B.Right;
        if (p->B.Left == nullptr)
        {
          p->B.Left = p->B.Right;
          NewPlotLine();
          AddLineToAnswerTable();
        } else
          return true;
      } break;
  }
  return false;
}

bool increment_generators()
{
  int8_t y;
  bool result;

  result = false;
  for (y = maxLine; y>=minLine; y--)
    if (! result)
      result = increment_generator(equations[y].tree);
  return result;
}

bool solve_screen()
{
  if (has_fors)
    ResetTable();

  int8_t aminLine = 1;
  int8_t amaxLine = NumEqus;
  Pnode p;
  int8_t pass,y;
  bool all_known,done,result;

  minLine = aminLine;
  maxLine = amaxLine;
  do {
    p = global_name_list;
    while (p != nullptr)
    {
      p->V.status = unknown;
      p = p->V.nextV;
    }

    for (y = minLine; y<=maxLine; y++)
      equations[y].equal = true;

    for (pass = 1; pass<=2; pass++)
    {
      do {
        done = true;
        for (y = minLine; y<=maxLine; y++)
          if ((pass == 1) == equations[y].has_init)
            if (to_be_solved(y))
              if (solve(y))
              {
                done = false;
                all_known = write_knowns(global_name_list,false);
              }
        all_known = write_knowns(global_name_list,false);
        if ((pass == 2) && done && ! all_known)
          if (Simult())
            done = false;
      } while (!done);
      
      p = global_name_list;
      while ((pass==1) && (p != nullptr))
      {
        if (p->V.status == known) p->V.init_value = p->V.value;
        p->V.status = unknown;
        p = p->V.nextV;
      }
    }

    CoordsFound();

    if (check_equal())
      result = write_knowns(global_name_list,true); else
    {
      if (has_fors || has_plot)
        result = write_knowns(global_name_list,true);
      result = false;
    }

    if (has_plot)
      AllCoordsFound();
  } while (increment_generators());

  return result;
}

bool parse_strings()
{
  int8_t y,cursor;

  global_name_list = nullptr;
  has_qus = false;
  has_fors = false;
  has_plot = false;
  ResetPlot();
  DeleteAnswers();
  NumEqus = 0;
  memset(equations,0,sizeof(equations));
  for (y = 1; y<=NumLines; y++)
  {
    local_name_list = nullptr;
    equations[NumEqus+1].ScreenLine = y;
    equations[NumEqus+1].depend = nullptr;
    equations[NumEqus+1].has_init = false;
    equations[NumEqus+1].equal = false;
    equations[NumEqus+1].uselist = nullptr;
    equations[NumEqus+1].tree = nullptr;
    hasQuInLine = false;

    if (equation(lines[y-1],&cursor,NumEqus+1,&(equations[NumEqus+1].has_init)))
    {
      equations[NumEqus+1].uselist = local_name_list;
      if (equations[NumEqus+1].tree != nullptr)
      {
        if (NumEqus == equMax)
            {
              RunError(equations[NumEqus+1].ScreenLine-1,-2);
              return false;
            } else
              NumEqus++;
      }
    } else
    {
      ShowErrorAt(cursor,equations[NumEqus+1].ScreenLine-1,"");
      return false;
    }
  }
  return true;
}

void AddQus()
{
  Pnode v;

  v = global_name_list;
  while (v != nullptr)
  {
    AddQuLine(v->V.name);
    v = v->V.nextV;
  }
}

bool has_var(char *c)
{
  Pnode p;
  p = global_name_list;
  while (p != nullptr)
  {
    if (strcmp(p->V.name,c) == 0)
      return true;
    p = p->V.nextV;
  }
  return false;
}

bool solve_strings()
{
  Pnode p;

  FreeAllMemory();
  has_plot = false;
  ResetPlot();

  if (parse_strings())
  {
    if (! has_plot && ! has_qus && has_var("X") && has_var("Y") && has_fors)
    {
      has_plot = true;
      is3Dplot = has_var("Z");
    }

    if (! has_plot && ! has_qus)
    {
      AddQus();
      parse_strings();
    }

    if (has_qus)
      has_plot = false;

    is_solving = true;
    if (! solve_screen())
    {
      has_qus = false;
      has_plot = false;
    }
    is_solving = false;
    return true;
  }
  return false;
}
