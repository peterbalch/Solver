//==============
// Table.h
//==============

#ifndef Table_h
#define Table_h

void DrawImageTable();
void TableFormKeyPress(char Key);
void ResetTable();
void AddNumToAnswerTable(double value);
void AddQuToAnswerTable();
void AddLineToAnswerTable();

#endif
