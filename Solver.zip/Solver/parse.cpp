//==============
// parse.cpp
//==============

#include "parse.h"
//#include "solver.h"
#include <stdint.h>
#include "math.h"
#include "calc.h"
#include "calcdecl.h"
//#include "gauss.h"
//#include "plotter.h"
//#include "table.h"
#include "VDU.h"
#include "string.h"
//#include "storage.h"
//#include "parse.h"
//#include <limits.h>
#include "memory.h"
#include <ctype.h>
#include <stdio.h>

char *cursor;
int8_t cur_equ;
char *curstring;
bool MustBeConstant;
bool equ_has_init;
bool HasAdvanced;

void upper(char *s)
{
  while (*s != 0)
    *s = toupper(*s);
}

void skipBlanks()
{
  while (true) {
    if ((*cursor == '/') && (cursor[1] == '/'))
    {
      while (*cursor != 0)
        cursor++;
      return;
    }

    if (*cursor == 0)
      return;
    if (*cursor == ' ') cursor++; else
    if (*cursor == 9 ) cursor++; else
      return;
  }
}

bool nextis(char *s)
{
  char *p;
  bool b;

  skipBlanks();
  p = cursor;

  b = isalnum(*s);

  while (*s != 0)
  {
    if (toupper(*p) != toupper(*s))
      return false;
    p++;
    s++;
  }

  if (*p != 0)
    if (b)
      if (isalnum(*p))
        return false;

  cursor = p;

  skipBlanks();
  return true;
}

void binary(Toperation oper, Pnode *ans, Pnode r)
{
  Pnode t;
  t = new_node(oper);
  if (t == nullptr)
    return;
  t->B.Left = *ans;
  t->B.Right = r;
  *ans = t;
}

bool expr(Pnode *ans);

void get_id(char *s)
{
  int8_t i = 0;
  while ((*cursor != 0) && isalnum(*cursor))
  {
    if (i < lenNameStr)
      s[i] = toupper(*cursor);
    cursor++;
    i++;
  }
  if (i < lenNameStr)
    s[i] = 0;
  s[lenNameStr] = 0;
}

bool new_variable(Pnode *ans)
{
  char ss[lenNameStr+1];
  bool init;
  if (isalpha(*cursor) || (*cursor == '?'))
  {
    init = false;
    if (*cursor == '?')
    {
      if (hasQuInLine)
        return false;
      hasQuInLine = true;


      ss[0] = '?';
      ss[1] = 'S';
      ss[2] = 'a'+cur_equ-1;
      ss[3] = 'a'+(uint32_t)cursor-(uint32_t)curstring;
      ss[4] = 0;
      cursor = cursor+1;
      has_qus = true;
    } else
    {
      get_id(ss);
      if (strcmp(ss,"ITERATIONS") == 0)
        return false; else
      if (strcmp(ss,"ACCURACY") == 0)
        return false; else
      if (strcmp(ss,"INIT") == 0)
      {
        equ_has_init = true;
        init = true;
        if (*cursor != '(')
          return false; else
        {
          cursor = cursor+1;
    skipBlanks();
          if ((*cursor != 0) && isalpha(*cursor))
            get_id(ss); else
            return false;
    skipBlanks();
          if (*cursor != ')')
            return false; else
          cursor = cursor+1;
        }
      }
    }

    *ans = global_name_list;
    while (*ans != nullptr)
    {
      if (strcmp((*ans)->V.name,ss) == 0)
      {
        (*ans)->V.initialised = init;
        return true;
      }
      *ans = (*ans)->V.nextV;
    }

    *ans = new_node(opVar);
    if (*ans == nullptr)
      return false;
    {
      (*ans)->V.value = 0.0;
      (*ans)->V.init_value = 1.0;
      (*ans)->V.initialised = init;
      CopyStringN((*ans)->V.name,ss,lenNameStr);
      (*ans)->V.nextV = global_name_list;
      global_name_list = *ans;
    }
  } else
    return false;

  return true;
}

bool variable(Pnode *ans)
{
  PReferenceRec p;

  if (new_variable(ans))
  {
    if (MustBeConstant)
    {
      return false;
    } else
    {
      p = local_name_list;
      while (p != nullptr)
      {
        if (p->ref == *ans)
          return true;
        p = p->nextR;
      }

      return NewReferenceRec(*ans) != nullptr;
    }
  }
  return false;
}

bool num(Pnode *ans)
{
  double v1,v2;
  bool neg;
  int8_t error1,error2;
  char *oldcursor;

  oldcursor = cursor;
  if (isdigit(*cursor) || (*cursor == '.'))
  {
    *ans = new_node(opCnst);
    if (*ans == nullptr)
      return false;
    {
      v1 = 0;
      while (isdigit(*cursor))
      {
        v1 = v1*10+*cursor-'0';
        cursor++;
      }
      if (*cursor == '.')
      {
        cursor++;
        v2 = 1;
        while (isdigit(*cursor))
        {
          v1 = v1*10+*cursor-'0';
          v2 = v2*10;
          cursor++;
        }
        v1 = v1/v2;
      }

      if (toupper(*cursor) != 'E')
      {
        (*ans)->V.value = v1;
        return true;
      }

      cursor++;
      neg = false;
      if (*cursor == '+')
        cursor++; else
      if (*cursor == '-')
      {
        cursor++;
        neg = true;
      }

      if (!isdigit(*cursor))
      {
        cursor = oldcursor;
        return false;
      }

      v2 = 0;
      while (isdigit(*cursor))
      {
        v2 = v2*10+*cursor-'0';
        cursor++;
      }

      if (neg)
        (*ans)->V.value = execMultiply(v1,execPower(10,-v2,&error1),&error2); else
        (*ans)->V.value = execMultiply(v1,execPower(10,v2,&error1),&error2);
      return (error1 == 0) && (error2 == 0) && (((*ans)->V.value == 0) == (v1 == 0));
    }
  }
  return false;
}

void unary(Toperation oper, Pnode *ans)
{
  Pnode t;

  t = new_node(oper);
  if (t == nullptr)
    return;
  t->B.Left = *ans;
  t->B.Right = nullptr;
  *ans = t;
}

Pnode get_set()
{
  Pnode p;

  if (expr(&p))
  {
    if (nextis(",")) {
      binary(opSet_Fn,&p,get_set());
      if (p->B.Right == nullptr)
        return nullptr;
    } else
      binary(opSet_Fn,&p,nullptr);
    return p;
  } else
    return nullptr;
}

bool for_expr(Pnode *ans)
{
  Pnode r,t;
  
  if (MustBeConstant) return false;
  MustBeConstant = true;
  if (! expr(&r)) return false;

  if (nextis(","))
  {
    *ans = r;
    binary(opSet_Fn,ans,get_set());
    if ((*ans)->B.Right == nullptr)
      return false;
    binary(opSet_Fn,ans,*ans);
  } else
  {
    *ans = new_node(opCnst);
    if (*ans == nullptr)
      return false;
    (*ans)->V.initialised = false;
    binary(opFor_Fn,ans,r);
    if (! nextis("to") ) return false;
    if (! expr(&r)     ) return false;
    if (! nextis("by") ) return false;
    if (! expr(&t)     ) return false;
    binary(opFor_Fn,&r,t);
    binary(opFor_Fn,ans,r);
  }

  HasAdvanced = true;
  has_fors = true;
  MustBeConstant = false;
  return true;
}

bool NewConst(double a, Pnode *ans)
{
  *ans = new_node(opCnst);
  if (*ans == nullptr)
    return false;
  (*ans)->V.value = a;
  return true;
}

bool func(Toperation oper, Pnode *ans)
{
  if (! nextis("(") ) return false;
  if (expr(ans))
  {
    unary(oper,ans);
    return nextis(")");
  } else
    return false;
}

bool term(Pnode *ans)
{
  Pnode r,t;
  
  if (nextis("("))
  {
    if (expr(ans))
      return nextis(")"); else
      return false;
  } else
  if (nextis("sin")   ) return func(opSin_Fn, ans); else
  if (nextis("cos")   ) return func(opCos_Fn, ans); else
  if (nextis("tan")   ) return func(opTan_Fn, ans); else
  if (nextis("arcsin")) return func(opArcsin_Fn, ans); else
  if (nextis("arccos")) return func(opArccos_Fn, ans); else
  if (nextis("arctan")) return func(opArctan_Fn, ans); else
  if (nextis("deg")   ) return func(opDeg_Fn, ans); else
  if (nextis("rad")   ) return func(opRad_Fn, ans); else
  if (nextis("ln")    ) return func(opLn_Fn, ans); else
  if (nextis("exp")   ) return func(opExp_Fn, ans); else
  if (nextis("log")   ) return func(opLog_Fn, ans); else
  if (nextis("sqrt")  ) return func(opSqrt_Fn, ans); else
  if (nextis("sqr")   ) return func(opSqr_Fn, ans); else
  if (nextis("range") )
  {
    if (! nextis("(") ) return false;
    if (! expr(ans)   ) return false;
    if (! nextis(",") ) return false;
    MustBeConstant = true;
    if (! expr(&r)    ) return false;
    if (! nextis(",") ) return false;
    if (! expr(&t)    ) return false;
    if (! nextis(")") ) return false;
    MustBeConstant = false;
    binary(opRange_Fn,&r,t);
    binary(opRange_Fn,ans,r);
    return true;
  } else
  if (nextis("PI"))
    return NewConst(M_PI,ans); else
  if (nextis("ACCURACY"))
    return NewConst(Accuracy,ans); else
  if (nextis("ITERATIONS"))
    return NewConst(Iterations,ans); else
  if (num(ans))
    return true; else
  if (nextis("max("))
  {
    if (expr(ans))
    {
      while (nextis(","))
        if (expr(&r))
          binary(opMax_Fn,ans,r); else
          return false;
      return nextis(")");
    } else
      return false;
  } else
  if (nextis("min("))
  {
    if (expr(ans))
    {
      while (nextis(","))
        if (expr(&r))
          binary(opMin_Fn,ans,r); else
          return false;
      return nextis(")");
    } else
      return false;
  } else
  if (nextis("if"))
  {
    if (expr(ans))
    {
      if (! nextis("then") ) return false;
      if (! expr(&r)        ) return false;
      if (! nextis("else") ) return false;
      if (! expr(&t)        ) return false;
      binary(opIf_Fn,&r,t);
      binary(opIf_Fn,ans,r);
      return true;
    } else
      return false;
  } else
  if (nextis("for"))
  {
    return for_expr(ans);
  } else
//  if (num(ans))
//    return true; else
    return variable(ans);
}

bool power(Pnode *ans)
{
  Pnode r;
  
  if (term(ans))
  {
    while (nextis("^"))
      if (term(&r))
        binary(opPwr_Fn,ans,r); else
        return false;
    return true;
  } else
    return false;
}

bool mult(Pnode *ans)
{
  bool done,ok;
  Pnode r;

  if (power(ans))
  {
    done = false;
    ok = true;
    do {
      if (nextis("*") ) { ok = power(&r); binary(opMlt,   ans,r); } else
      if (nextis("/") ) { ok = power(&r); binary(opDivide,ans,r); } else
      if (nextis("\\") ) { ok = power(&r); binary(opRem,   ans,r); } else
        done = true;
    } while (!(done || !ok));
  } else
    ok = false;
  return ok;
}

bool add(Pnode *ans)
{
  bool negative,done,ok;
  Pnode r;
  
  negative = nextis("-");
  nextis("+");

  if (mult(ans))
  {
    if (negative) unary(opNeg,ans);

    ok = true;
    done = false;

    do {
      if (nextis("+") ) { ok = mult(&r); binary(opPlus, ans,r); } else
      if (nextis("-") ) { ok = mult(&r); binary(opMinus,ans,r); } else
        done = true;
    } while (!(done || !ok));
  } else
    ok = false;
  return ok;
}

bool expr(Pnode *ans)
{
  return add(ans);
}

bool assignment(char *s, Pnode *ans)
{
  Pnode r;

  if (expr(ans))
  {
    if (*cursor == 0)
    {
      InsertChar(s,' ',1000);
      InsertChar(s,'=',1000);
      InsertChar(s,' ',1000);
      InsertChar(s,'?',1000);
      cursor = s;
      curstring = s;
      if (! expr(ans))
        return false;
    }

    if (nextis("=") && expr(&r))
    {
      binary(opMinus,ans,r);
      return *cursor == 0;
    }
  }
  return false;
}

bool equation(char *s, int8_t *c, int8_t l, bool *init)
{
  HasAdvanced = false;
  equations[l].tree = nullptr;

  cursor = s;
  curstring = s;

  skipBlanks();
  if (*cursor == 0)
    return true;

  cur_equ = l;
  equ_has_init = false;
  MustBeConstant = false;

  if (assignment(s,&(equations[l].tree))) {
    *c = cursor - curstring;
    *init = equ_has_init;
    return true;
  } else {
    *c = cursor - curstring;
    *init = false;
    return false;
  }
}
