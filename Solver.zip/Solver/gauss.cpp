//==============
// gauss.cpp
//==============

#include "gauss.h"
#include <stdint.h>
#include "memory.h"
#include "math.h"

int8_t matSize;
double *Matrix,*TestMatrix;
int8_t curMatSize;

void ResetMatrix()
{
  curMatSize = 0;
}

bool AllocateMatrix()
{
  if (matSize == curMatSize)
    return true;
  curMatSize = matSize;

  Matrix = (double*)GetBufferMemory((1+matSize)*matSize*sizeof(double));
  if (Matrix == nullptr)
    return false;
  TestMatrix = (double*)GetBufferMemory((1+matSize)*matSize*sizeof(double));
  return TestMatrix != nullptr;
}

void setMatrix(int8_t x,int8_t y, double a)
{
  Matrix[(x-1)*(1+matSize)+y] = a;
}

double getMatrix(int8_t x,int8_t y)
{
  return Matrix[(x-1)*(1+matSize)+y];
}

double getTestMatrix(int8_t x,int8_t y)
{
  return TestMatrix[(x-1)*(1+matSize)+y];
}

void setTestMatrix(int8_t x,int8_t y, double a)
{
  TestMatrix[(x-1)*(1+matSize)+y] = a;
}

bool gaussian_eliminate()
{
  int8_t i,j,k,l;
  double r;
  for (k = 1; k<= matSize; k++)
  {
    /* swap to biggest pivot */
    l = k;
    for (i = k+1; i<= matSize; i++)
      if (fabs(getMatrix(i,k)) > fabs(getMatrix(l,k))) l = i;
    if (l != k)
      for (j = 0; j<= matSize; j++)
        { r = getMatrix(k,j); setMatrix(k,j,getMatrix(l,j)); setMatrix(l,j,r); }

    /* set diagonal element to -1 */
    if (getMatrix(k,k) == 0)
      return false;
    r = -1/getMatrix(k,k);
    for (j = 0; j<= matSize; j++)
      setMatrix(k,j,getMatrix(k,j)*r);

    /* set lower part of column to 0 */
    for (i = 1; i<= matSize; i++)
    if ((i != k) && (getMatrix(i,k) != 0))
    {
      r = getMatrix(i,k);
      for (j = 0; j<= matSize; j++)
        setMatrix(i,j,getMatrix(i,j)+getMatrix(k,j)*r);
    }
  }

  return true;
}
