//==============
// calcdecl.h
//==============

#ifndef calcdecl_h
#define calcdecl_h

#include <stdint.h>

#define equMax 100
#define lenNameStr 10
//#define PI M_PI

#define Key_DOWN     ((char)140)
#define Key_EXECUTE  ((char)141)
#define Key_LEFT     ((char)142)
#define Key_RIGHT    ((char)143)
#define Key_SELECT   ((char)144)
#define Key_UP       ((char)145)
#define Key_BACK     ((char)146)

#define Key_DELETE   ((char)147)    // not used in calculator
#define Key_END      ((char)148)    // not used in calculator
#define Key_HOME     ((char)149)    // not used in calculator

#define CurFont LargeFont
//#define CurFont CompactFont

#define TXTH TextHeight(CurFont)+1
#define odd(i) ((i & 1) > 0)

enum Toperation {opNeg,opPlus,opMinus,opMlt,opDivide,opRem,opPwr_Fn,opCnst,opVar,
               opSin_Fn,opCos_Fn,opTan_Fn,opArcsin_Fn,opArccos_Fn,opArctan_Fn,
               opRad_Fn,opDeg_Fn,opLn_Fn,opExp_Fn,opLog_Fn,opSqrt_Fn,opSqr_Fn,
               opRange_Fn,opAsgn,
               opMin_Fn,opMax_Fn,opIf_Fn,opFor_Fn,opSet_Fn,
               opRecip}; //opRecip is only used while folding consts
//  TsetofToperation = set of Toperation;
enum Tstatus_type {known,unknown,unwanted};

typedef union Tnode Tnode;
typedef Tnode *Pnode;
struct TBinNode {Toperation op; Pnode Left; Pnode Right;};
struct TVarNode {
  Toperation op;
  double value;
  double init_value;
  char name[lenNameStr+1];
  bool initialised;
  Pnode nextV;
  Tstatus_type status;};

union Tnode {
  TBinNode B;
  TVarNode V;};

typedef struct TReferenceRec TReferenceRec;
typedef TReferenceRec *PReferenceRec;

struct TReferenceRec {
    Pnode ref;
    PReferenceRec nextR;};

struct TequRec {
    Pnode depend;
    bool has_init;
    bool equal;
    PReferenceRec uselist;
    Pnode tree;
    uint16_t ScreenLine;
  };

enum Tlayout {lyRight,lyLeft,lyCentre,lyUp,lyDown};

extern double MaxRealDbl;
extern float MaxRealSgl;
extern Pnode global_name_list;
extern PReferenceRec local_name_list;
extern TequRec equations[equMax+2];
extern bool has_qus,has_fors,has_plot;
extern bool is_solving;
extern bool is3Dplot;
extern bool hasQuInLine;

extern uint16_t Iterations;
extern double Accuracy;
#define NumLength 10

char *real_str(double r);
double safeDiv(double a, double b);
int32_t safeTrunc(double r);
void CopyStringN(char *dest, char *src, int8_t n);
//int32_t constrain(int32_t a, int32_t min, int32_t max); // in arduino
void Delay(int32_t msecs);

double frac(double a);

#endif
